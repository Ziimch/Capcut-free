plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// Set by the GitHub workflow: -PappVersionCode=<n> -PgithubRepo=<owner/repo>
val appVersionCode = (project.findProperty("appVersionCode") as String?)?.toIntOrNull() ?: 1
val githubRepo = (project.findProperty("githubRepo") as String?) ?: ""

android {
    namespace = "com.freeeditor"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.freeeditor.app"
        minSdk = 26
        targetSdk = 34
        versionCode = appVersionCode
        versionName = "0.9.$appVersionCode"
        buildConfigField("String", "GITHUB_REPO", "\"$githubRepo\"")
    }
    signingConfigs {
        // One fixed key for every build, so each APK can update the previous one.
        create("app") {
            storeFile = rootProject.file("keystore/release.jks")
            storePassword = "freeeditor"
            keyAlias = "freeeditor"
            keyPassword = "freeeditor"
        }
    }
    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("app")
        }
        debug { signingConfig = signingConfigs.getByName("app") }
    }
    buildFeatures { compose = true; buildConfig = true }
    composeOptions { kotlinCompilerExtensionVersion = "1.5.14" }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
        freeCompilerArgs += "-opt-in=androidx.media3.common.util.UnstableApi"
    }
    lint { abortOnError = false; checkReleaseBuilds = false }
    packaging { resources.excludes += "/META-INF/{AL2.0,LGPL2.1}" }
}
dependencies {
    val media3 = "1.3.1"
    implementation(platform("androidx.compose:compose-bom:2024.06.00"))
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.activity:activity-compose:1.9.0")
    implementation("androidx.media3:media3-exoplayer:$media3")
    implementation("androidx.media3:media3-ui:$media3")
    implementation("androidx.media3:media3-transformer:$media3")
    implementation("androidx.media3:media3-common:$media3")
    implementation("androidx.media3:media3-effect:$media3")
}
