package com.freeeditor

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.graphics.RectF
import android.media.MediaMetadataRetriever
import android.net.Uri

/** Renders one still frame (video frame + color fx + all layers) at timeline position [ms]. Call off the main thread. */
object FrameExport {
    fun render(ctx: Context, p: Project, ms: Long): Bitmap? {
        val clips = p.clips
        if (clips.isEmpty()) return null
        var acc = 0L; var clip = clips.last(); var off = clip.durationMs
        for (c in clips) {
            if (ms < acc + c.durationMs) { clip = c; off = ms - acc; break }
            acc += c.durationMs
        }
        val (w, h) = canvasSize(p)
        val t = clip.inMs + off.coerceIn(0L, maxOf(clip.durationMs - 1, 0L))
        val frame = runCatching {
            val r = MediaMetadataRetriever()
            try {
                r.setDataSource(ctx, Uri.parse(clip.uri))
                r.getFrameAtTime(t * 1000, MediaMetadataRetriever.OPTION_CLOSEST)
            } finally { r.release() }
        }.getOrNull() ?: return null
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        c.drawColor(Color.BLACK)
        val fx = clip.fx
        val sx = w / frame.width.toFloat(); val sy = h / frame.height.toFloat()
        val s = if (p.fit) minOf(sx, sy) else maxOf(sx, sy)
        val dw = frame.width * s; val dh = frame.height * s
        val paint = Paint(Paint.FILTER_BITMAP_FLAG)
        if (fx.hasColor) paint.colorFilter = ColorMatrixColorFilter(
            buildColorMatrix(fx.brightness, fx.contrast, fx.saturation, fx.warmth, fx.filter, fx.filterAmt))
        c.save()
        if (fx.flipH || fx.flipV) c.scale(if (fx.flipH) -1f else 1f, if (fx.flipV) -1f else 1f, w / 2f, h / 2f)
        c.drawBitmap(frame, null, RectF((w - dw) / 2f, (h - dh) / 2f, (w + dw) / 2f, (h + dh) / 2f), paint)
        c.restore()
        LayerRender.draw(c, w, h, p.texts, p.images, p.shapes, ms, clips) { ImageCache.get(ctx, it) }
        frame.recycle()
        return out
    }
}
