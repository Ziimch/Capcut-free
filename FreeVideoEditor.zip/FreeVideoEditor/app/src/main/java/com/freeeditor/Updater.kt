package com.freeeditor

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/** In-app updater: reads the latest GitHub Release of this repo, downloads the APK and opens the installer. */
object Updater {
    class Info(val versionCode: Int, val name: String, val url: String)

    suspend fun check(): Result<Info?> = withContext(Dispatchers.IO) {
        runCatching {
            val repo = BuildConfig.GITHUB_REPO
            if (repo.isBlank()) error("Updates only work in builds made by GitHub Actions")
            val c = URL("https://api.github.com/repos/$repo/releases/latest").openConnection() as HttpURLConnection
            c.setRequestProperty("Accept", "application/vnd.github+json")
            c.setRequestProperty("User-Agent", "FreeVideoEditor")
            c.connectTimeout = 10000; c.readTimeout = 15000
            if (c.responseCode != 200) error("GitHub answered ${c.responseCode} (is the repo public?)")
            val o = JSONObject(c.inputStream.bufferedReader().use { it.readText() })
            val code = o.getString("tag_name").substringAfter("build-", "").toIntOrNull() ?: return@runCatching null
            val assets = o.getJSONArray("assets")
            var url: String? = null
            for (i in 0 until assets.length()) {
                val a = assets.getJSONObject(i)
                if (a.getString("name").endsWith(".apk")) url = a.getString("browser_download_url")
            }
            if (url != null && code > BuildConfig.VERSION_CODE) Info(code, o.optString("name", "Build $code"), url) else null
        }
    }

    suspend fun download(ctx: Context, info: Info, onProgress: (Int) -> Unit): File = withContext(Dispatchers.IO) {
        val dir = File(ctx.filesDir, "updates").apply { mkdirs(); listFiles()?.forEach { it.delete() } }
        val f = File(dir, "update_${info.versionCode}.apk")
        val c = URL(info.url).openConnection() as HttpURLConnection
        c.instanceFollowRedirects = true
        c.connectTimeout = 15000; c.readTimeout = 30000
        val total = c.contentLengthLong
        c.inputStream.use { input ->
            f.outputStream().use { out ->
                val buf = ByteArray(64 * 1024); var done = 0L; var n: Int
                while (input.read(buf).also { n = it } >= 0) {
                    out.write(buf, 0, n); done += n
                    if (total > 0) onProgress((done * 100 / total).toInt())
                }
            }
        }
        f
    }

    /** Returns false when the user must first allow "install unknown apps" for this app. */
    fun install(ctx: Context, apk: File): Boolean {
        if (!ctx.packageManager.canRequestPackageInstalls()) {
            ctx.startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${ctx.packageName}"))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            return false
        }
        val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", apk)
        ctx.startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(uri, "application/vnd.android.package-archive")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK))
        return true
    }
}

@Composable
fun UpdateCard() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var info by remember { mutableStateOf<Updater.Info?>(null) }
    var status by remember { mutableStateOf("Version ${BuildConfig.VERSION_NAME}") }
    var checking by remember { mutableStateOf(false) }
    var progress by remember { mutableStateOf<Int?>(null) }

    fun check(manual: Boolean) {
        scope.launch {
            checking = true
            val r = Updater.check()
            checking = false
            r.onSuccess {
                info = it
                status = if (it == null) "Version ${BuildConfig.VERSION_NAME} - up to date" else "New version available: ${it.name}"
            }
            r.onFailure { if (manual) status = "Update check failed: ${it.message}" }
        }
    }
    LaunchedEffect(Unit) { check(false) }

    Surface(shape = RoundedCornerShape(16.dp), color = MaterialTheme.colorScheme.surface, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(status, style = MaterialTheme.typography.bodyMedium)
            progress?.let { LinearProgressIndicator(progress = { it / 100f }, modifier = Modifier.fillMaxWidth()) }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(enabled = !checking && progress == null, onClick = { check(true) }) {
                    Text(if (checking) "Checking..." else "Check for updates")
                }
                info?.let { i ->
                    Button(enabled = progress == null, onClick = {
                        scope.launch {
                            progress = 0
                            runCatching { Updater.download(ctx, i) { p -> progress = p } }
                                .onSuccess {
                                    progress = null
                                    if (!Updater.install(ctx, it)) status = "Allow \"install unknown apps\" for this app, then tap Update again"
                                }
                                .onFailure { progress = null; status = "Download failed: ${it.message}" }
                        }
                    }) { Text("Update") }
                }
            }
        }
    }
}
