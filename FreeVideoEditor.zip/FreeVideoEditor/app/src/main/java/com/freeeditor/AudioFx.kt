package com.freeeditor

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import androidx.media3.common.C
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.BaseAudioProcessor
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.UUID
import kotlin.math.abs
import kotlin.math.sqrt

/** Volume + fade-in/out applied to 16-bit PCM during export. Position is counted in processed frames. */
class GainFadeProcessor(
    private val volume: Float,
    private val fadeInMs: Long,
    private val fadeOutMs: Long,
    private val durationMs: Long,
) : BaseAudioProcessor() {
    private var frames = 0L

    override fun onConfigure(inputAudioFormat: AudioProcessor.AudioFormat): AudioProcessor.AudioFormat {
        if (inputAudioFormat.encoding != C.ENCODING_PCM_16BIT) {
            throw AudioProcessor.UnhandledAudioFormatException(inputAudioFormat)
        }
        return inputAudioFormat
    }

    override fun onFlush() { frames = 0 }

    override fun queueInput(inputBuffer: ByteBuffer) {
        val channels = inputAudioFormat.channelCount
        val rate = inputAudioFormat.sampleRate
        val out = replaceOutputBuffer(inputBuffer.remaining()).order(ByteOrder.LITTLE_ENDIAN)
        inputBuffer.order(ByteOrder.LITTLE_ENDIAN)
        while (inputBuffer.remaining() >= 2 * channels) {
            val tMs = frames * 1000f / rate
            var g = volume
            if (fadeInMs > 0) g *= (tMs / fadeInMs).coerceIn(0f, 1f)
            if (fadeOutMs > 0) g *= ((durationMs - tMs) / fadeOutMs).coerceIn(0f, 1f)
            for (c in 0 until channels) {
                val v = (inputBuffer.short * g).toInt().coerceIn(-32768, 32767)
                out.putShort(v.toShort())
            }
            frames++
        }
        out.flip()
    }
}

/** Writes a silent 44.1 kHz stereo WAV so audio can start at a timeline offset during export. */
object Silence {
    fun create(ctx: Context, ms: Long): File {
        val f = File(ctx.cacheDir, "silence_${UUID.randomUUID()}.wav")
        val rate = 44100; val ch = 2
        val dataLen = (ms * rate / 1000).toInt() * ch * 2
        f.outputStream().buffered().use { o ->
            fun i32(v: Int) = o.write(byteArrayOf(v.toByte(), (v shr 8).toByte(), (v shr 16).toByte(), (v shr 24).toByte()))
            fun i16(v: Int) = o.write(byteArrayOf(v.toByte(), (v shr 8).toByte()))
            o.write("RIFF".toByteArray()); i32(36 + dataLen); o.write("WAVEfmt ".toByteArray())
            i32(16); i16(1); i16(ch); i32(rate); i32(rate * ch * 2); i16(ch * 2); i16(16)
            o.write("data".toByteArray()); i32(dataLen)
            val zeros = ByteArray(64 * 1024); var left = dataLen
            while (left > 0) { val n = minOf(left, zeros.size); o.write(zeros, 0, n); left -= n }
        }
        return f
    }
}

/** Decodes audio and returns loudness peaks (PPS per second) for drawing real waveforms. */
object Waveform {
    const val PPS = 20
    private val cache = HashMap<String, FloatArray>()

    fun load(ctx: Context, uri: String): FloatArray? {
        synchronized(cache) { cache[uri]?.let { return it } }
        val ex = MediaExtractor()
        var codec: MediaCodec? = null
        try {
            ex.setDataSource(ctx, Uri.parse(uri), null)
            var track = -1; var fmt: MediaFormat? = null
            for (i in 0 until ex.trackCount) {
                val f = ex.getTrackFormat(i)
                if (f.getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true) { track = i; fmt = f; break }
            }
            if (track < 0 || fmt == null) return null
            ex.selectTrack(track)
            codec = MediaCodec.createDecoderByType(fmt.getString(MediaFormat.KEY_MIME)!!)
            codec.configure(fmt, null, null, 0); codec.start()
            var rate = fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            var ch = fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
            val info = MediaCodec.BufferInfo()
            val peaks = ArrayList<Float>()
            var inDone = false; var outDone = false
            var framesInPeak = 0; var peak = 0f
            while (!outDone) {
                if (!inDone) {
                    val ii = codec.dequeueInputBuffer(10_000)
                    if (ii >= 0) {
                        val n = ex.readSampleData(codec.getInputBuffer(ii)!!, 0)
                        if (n < 0) { codec.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM); inDone = true }
                        else { codec.queueInputBuffer(ii, 0, n, ex.sampleTime, 0); ex.advance() }
                    }
                }
                val oi = codec.dequeueOutputBuffer(info, 10_000)
                if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    val of = codec.outputFormat
                    rate = of.getInteger(MediaFormat.KEY_SAMPLE_RATE); ch = of.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                } else if (oi >= 0) {
                    val ob = codec.getOutputBuffer(oi)!!
                    ob.position(info.offset); ob.limit(info.offset + info.size)
                    val sb = ob.order(ByteOrder.LITTLE_ENDIAN).asShortBuffer()
                    val perPeak = (rate / PPS).coerceAtLeast(1)
                    while (sb.remaining() >= ch) {
                        var m = 0
                        for (c in 0 until ch) m = maxOf(m, abs(sb.get().toInt()))
                        peak = maxOf(peak, m / 32768f)
                        if (++framesInPeak >= perPeak) { peaks.add(sqrt(peak)); peak = 0f; framesInPeak = 0 }
                    }
                    codec.releaseOutputBuffer(oi, false)
                    if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outDone = true
                }
            }
            val arr = peaks.toFloatArray()
            synchronized(cache) { cache[uri] = arr }
            return arr
        } catch (_: Exception) {
            return null
        } finally {
            runCatching { codec?.stop() }; runCatching { codec?.release() }; ex.release()
        }
    }
}
