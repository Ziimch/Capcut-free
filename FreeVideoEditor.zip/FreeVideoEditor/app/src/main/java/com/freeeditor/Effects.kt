package com.freeeditor

import android.graphics.Bitmap
import android.graphics.BlurMaskFilter
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.media3.common.Effect
import androidx.media3.effect.MatrixTransformation
import androidx.media3.effect.RgbMatrix
import org.json.JSONObject
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin
import kotlin.math.sqrt

val FILTERS = listOf("NONE", "MONO", "NOIR", "SEPIA", "INVERT", "WARM", "COOL", "VINTAGE", "VIVID")
val MOTIONS = listOf("NONE", "ZOOM_IN", "ZOOM_OUT", "PULSE", "SHAKE")

data class ClipFx(
    val brightness: Float = 0f,     // -0.5..0.5
    val contrast: Float = 1f,       // 0.5..1.8
    val saturation: Float = 1f,     // 0..2
    val warmth: Float = 0f,         // -1..1
    val filter: String = "NONE",
    val filterAmt: Float = 1f,
    val vignette: Float = 0f,       // 0..1
    val motion: String = "NONE",
    val motionAmt: Float = 0.5f,
) {
    val hasColor: Boolean get() = brightness != 0f || contrast != 1f || saturation != 1f || warmth != 0f || filter != "NONE"
    val isNone: Boolean get() = !hasColor && motion == "NONE" && vignette <= 0.01f
}

data class LayerFx(
    val shadow: Float = 0f,         // 0..1
    val glow: Float = 0f,           // 0..1
    val glowColor: Int = 0xFF4DD0E1.toInt(),
    val blur: Float = 0f,           // 0..1
    val brightness: Float = 0f,
    val contrast: Float = 1f,
    val saturation: Float = 1f,
) {
    val hasColor: Boolean get() = brightness != 0f || contrast != 1f || saturation != 1f
    val isNone: Boolean get() = shadow <= 0.01f && glow <= 0.01f && blur <= 0.01f && !hasColor
}

fun clipFxToJson(f: ClipFx): JSONObject = JSONObject()
    .put("b", f.brightness.toDouble()).put("c", f.contrast.toDouble()).put("s", f.saturation.toDouble())
    .put("w", f.warmth.toDouble()).put("f", f.filter).put("fa", f.filterAmt.toDouble())
    .put("v", f.vignette.toDouble()).put("m", f.motion).put("ma", f.motionAmt.toDouble())

fun clipFxFromJson(o: JSONObject?): ClipFx {
    if (o == null) return ClipFx()
    return ClipFx(
        brightness = o.optDouble("b", 0.0).toFloat(), contrast = o.optDouble("c", 1.0).toFloat(),
        saturation = o.optDouble("s", 1.0).toFloat(), warmth = o.optDouble("w", 0.0).toFloat(),
        filter = o.optString("f", "NONE"), filterAmt = o.optDouble("fa", 1.0).toFloat(),
        vignette = o.optDouble("v", 0.0).toFloat(), motion = o.optString("m", "NONE"),
        motionAmt = o.optDouble("ma", 0.5).toFloat(),
    )
}

fun layerFxToJson(f: LayerFx): JSONObject = JSONObject()
    .put("sh", f.shadow.toDouble()).put("gl", f.glow.toDouble()).put("gc", f.glowColor)
    .put("bl", f.blur.toDouble()).put("b", f.brightness.toDouble()).put("c", f.contrast.toDouble())
    .put("s", f.saturation.toDouble())

fun layerFxFromJson(o: JSONObject?): LayerFx {
    if (o == null) return LayerFx()
    return LayerFx(
        shadow = o.optDouble("sh", 0.0).toFloat(), glow = o.optDouble("gl", 0.0).toFloat(),
        glowColor = o.optInt("gc", 0xFF4DD0E1.toInt()), blur = o.optDouble("bl", 0.0).toFloat(),
        brightness = o.optDouble("b", 0.0).toFloat(), contrast = o.optDouble("c", 1.0).toFloat(),
        saturation = o.optDouble("s", 1.0).toFloat(),
    )
}

/** Clip containing the timeline position [ms] (the last clip if past the end). */
fun clipAt(clips: List<Clip>, ms: Long): Clip? {
    var acc = 0L
    for (c in clips) { if (ms < acc + c.durationMs) return c; acc += c.durationMs }
    return clips.lastOrNull()
}

// ---------- Color math (shared by video clips and overlay layers) ----------
private fun cm(vararg v: Float) = ColorMatrix(floatArrayOf(*v))

private fun contrastMatrix(c: Float, brightness: Float): ColorMatrix {
    val t = (0.5f * (1f - c) + brightness) * 255f
    return cm(c, 0f, 0f, 0f, t, 0f, c, 0f, 0f, t, 0f, 0f, c, 0f, t, 0f, 0f, 0f, 1f, 0f)
}

private fun satMatrix(s: Float): ColorMatrix { val m = ColorMatrix(); m.setSaturation(s); return m }

private fun filterMatrix(name: String): ColorMatrix? = when (name) {
    "MONO" -> satMatrix(0f)
    "NOIR" -> satMatrix(0f).also { it.postConcat(contrastMatrix(1.4f, 0f)) }
    "SEPIA" -> cm(0.393f, 0.769f, 0.189f, 0f, 0f, 0.349f, 0.686f, 0.168f, 0f, 0f, 0.272f, 0.534f, 0.131f, 0f, 0f, 0f, 0f, 0f, 1f, 0f)
    "INVERT" -> cm(-1f, 0f, 0f, 0f, 255f, 0f, -1f, 0f, 0f, 255f, 0f, 0f, -1f, 0f, 255f, 0f, 0f, 0f, 1f, 0f)
    "WARM" -> cm(1.12f, 0f, 0f, 0f, 6f, 0f, 1.02f, 0f, 0f, 0f, 0f, 0f, 0.88f, 0f, -6f, 0f, 0f, 0f, 1f, 0f)
    "COOL" -> cm(0.9f, 0f, 0f, 0f, -4f, 0f, 1f, 0f, 0f, 0f, 0f, 0f, 1.12f, 0f, 8f, 0f, 0f, 0f, 1f, 0f)
    "VINTAGE" -> satMatrix(0.6f).also {
        it.postConcat(cm(1.05f, 0f, 0f, 0f, 18f, 0f, 1f, 0f, 0f, 10f, 0f, 0f, 0.85f, 0f, 0f, 0f, 0f, 0f, 1f, 0f))
        it.postConcat(contrastMatrix(0.9f, 0f))
    }
    "VIVID" -> satMatrix(1.5f).also { it.postConcat(contrastMatrix(1.1f, 0f)) }
    else -> null
}

private fun lerpMatrix(m: ColorMatrix, amt: Float): ColorMatrix {
    val id = ColorMatrix().array; val a = m.array
    return ColorMatrix(FloatArray(20) { id[it] + (a[it] - id[it]) * amt })
}

fun buildColorMatrix(brightness: Float, contrast: Float, saturation: Float, warmth: Float, filter: String, filterAmt: Float): ColorMatrix {
    val m = ColorMatrix()
    if (saturation != 1f) m.postConcat(satMatrix(saturation))
    if (contrast != 1f || brightness != 0f) m.postConcat(contrastMatrix(contrast, brightness))
    if (warmth != 0f) m.postConcat(cm(1f + 0.25f * warmth, 0f, 0f, 0f, 0f, 0f, 1f, 0f, 0f, 0f, 0f, 0f, 1f - 0.25f * warmth, 0f, 0f, 0f, 0f, 0f, 1f, 0f))
    filterMatrix(filter)?.let { m.postConcat(lerpMatrix(it, filterAmt.coerceIn(0f, 1f))) }
    return m
}

/** Android 4x5 color matrix -> column-major 4x4 for Media3 RgbMatrix (offsets ride on alpha = 1). */
private fun toGlMatrix(c: ColorMatrix): FloatArray {
    val a = c.array; val m = FloatArray(16)
    for (r in 0 until 4) {
        for (col in 0 until 4) m[col * 4 + r] = a[r * 5 + col]
        m[12 + r] += a[r * 5 + 4] / 255f
    }
    return m
}

private fun motionMatrix(fx: ClipFx, tUs: Long, durUs: Long): Matrix {
    val a = fx.motionAmt.coerceIn(0f, 1f)
    val p = (tUs.toFloat() / durUs.toFloat()).coerceIn(0f, 1f)
    val ts = tUs / 1_000_000f
    var s = 1f; var dx = 0f; var dy = 0f
    when (fx.motion) {
        "ZOOM_IN" -> s = 1f + 0.35f * a * p
        "ZOOM_OUT" -> s = 1f + 0.35f * a * (1f - p)
        "PULSE" -> s = 1f + 0.10f * a * (0.5f - 0.5f * cos(ts * 10.47f))   // ~0.6 s period
        "SHAKE" -> { s = 1f + 0.06f * a; dx = 0.025f * a * sin(ts * 47f); dy = 0.025f * a * cos(ts * 61f) }
    }
    val m = Matrix()
    m.postScale(s, s); m.postTranslate(dx, dy)
    return m
}

/** GL effects for one video clip. Same list is used by the exporter and the live preview. */
object ClipFxBuild {
    fun effects(c: Clip): List<Effect> {
        val fx = c.fx
        val out = ArrayList<Effect>()
        if (fx.hasColor) {
            val gl = toGlMatrix(buildColorMatrix(fx.brightness, fx.contrast, fx.saturation, fx.warmth, fx.filter, fx.filterAmt))
            out.add(object : RgbMatrix {
                override fun getMatrix(presentationTimeUs: Long, useHdr: Boolean): FloatArray = gl
            })
        }
        if (fx.motion != "NONE") {
            val durUs = (c.durationMs * 1000L).coerceAtLeast(1L)
            out.add(object : MatrixTransformation {
                override fun getMatrix(presentationTimeUs: Long): Matrix = motionMatrix(fx, presentationTimeUs, durUs)
            })
        }
        return out
    }
}

// ---------- Canvas effects (overlay layers + vignette) ----------
object FxRender {
    fun vignette(canvas: Canvas, w: Int, h: Int, amt: Float) {
        val a = amt.coerceIn(0f, 1f)
        val r = 0.5f * hypot(w.toFloat(), h.toFloat())
        val inner = (0.75f - 0.4f * a).coerceIn(0.2f, 0.75f)
        val p = Paint().apply {
            shader = RadialGradient(w / 2f, h / 2f, r, intArrayOf(0x00000000, 0x00000000, Color.argb((255 * (0.35f + 0.65f * a)).toInt(), 0, 0, 0)),
                floatArrayOf(0f, inner, 1f), Shader.TileMode.CLAMP)
        }
        canvas.drawRect(0f, 0f, w.toFloat(), h.toFloat(), p)
    }

    private fun halo(canvas: Canvas, src: Bitmap, radius: Float, color: Int, dx: Float, dy: Float) {
        val off = IntArray(2)
        val blurPaint = Paint().apply { maskFilter = BlurMaskFilter(radius.coerceAtLeast(1f), BlurMaskFilter.Blur.NORMAL) }
        val mask = src.extractAlpha(blurPaint, off)
        canvas.drawBitmap(mask, off[0] + dx, off[1] + dy, Paint().apply { this.color = color })
        mask.recycle()
    }

    /** Approximate blur: shrink then enlarge with bilinear filtering. */
    private fun blurred(src: Bitmap, amt: Float): Bitmap {
        val f = 1f + amt.coerceIn(0f, 1f) * 20f
        val sw = (src.width / f).toInt().coerceAtLeast(2); val sh = (src.height / f).toInt().coerceAtLeast(2)
        val small = Bitmap.createScaledBitmap(src, sw, sh, true)
        val mid = Bitmap.createScaledBitmap(small, (sw * sqrt(f)).toInt().coerceAtLeast(2), (sh * sqrt(f)).toInt().coerceAtLeast(2), true)
        val big = Bitmap.createScaledBitmap(mid, src.width, src.height, true)
        if (small !== src && small !== big) small.recycle()
        if (mid !== src && mid !== big && mid !== small) mid.recycle()
        return big
    }

    /** Draws [src] (a full-frame transparent layer render) onto [canvas] with the layer's effects. */
    fun composite(canvas: Canvas, src: Bitmap, fx: LayerFx) {
        val w = src.width.toFloat()
        if (fx.shadow > 0.01f) {
            val r = fx.shadow * 0.02f * w
            halo(canvas, src, r, Color.argb(170, 0, 0, 0), r * 0.6f, r * 0.6f)
        }
        if (fx.glow > 0.01f) {
            val r = fx.glow * 0.04f * w
            val c = Color.argb(230, Color.red(fx.glowColor), Color.green(fx.glowColor), Color.blue(fx.glowColor))
            halo(canvas, src, r, c, 0f, 0f); halo(canvas, src, r * 0.5f, c, 0f, 0f)
        }
        val bmp = if (fx.blur > 0.01f) blurred(src, fx.blur) else src
        val p = Paint(Paint.FILTER_BITMAP_FLAG)
        if (fx.hasColor) p.colorFilter = ColorMatrixColorFilter(buildColorMatrix(fx.brightness, fx.contrast, fx.saturation, 0f, "NONE", 1f))
        canvas.drawBitmap(bmp, 0f, 0f, p)
        if (bmp !== src) bmp.recycle()
    }
}

// ---------- UI ----------
@Composable
private fun FxSlider(label: String, value: Float, range: ClosedFloatingPointRange<Float>, onChange: (Float) -> Unit) {
    Text("$label ${"%.2f".format(value)}", style = MaterialTheme.typography.labelSmall)
    Slider(value = value.coerceIn(range.start, range.endInclusive), onValueChange = onChange, valueRange = range)
}

private fun nice(s: String) = s.lowercase().replace('_', ' ').replaceFirstChar { it.uppercase() }

@Composable
fun ClipFxPanel(fx: ClipFx, onChange: (ClipFx, Boolean) -> Unit) {
    Column(Modifier.fillMaxWidth().heightIn(max = 230.dp).verticalScroll(rememberScrollState()).padding(horizontal = 12.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text("Filter", style = MaterialTheme.typography.labelSmall)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            FILTERS.forEach { f -> Chip(nice(f), fx.filter == f) { onChange(fx.copy(filter = f), true) } }
        }
        if (fx.filter != "NONE") FxSlider("Filter intensity", fx.filterAmt, 0f..1f) { onChange(fx.copy(filterAmt = it), false) }
        FxSlider("Brightness", fx.brightness, -0.5f..0.5f) { onChange(fx.copy(brightness = it), false) }
        FxSlider("Contrast", fx.contrast, 0.5f..1.8f) { onChange(fx.copy(contrast = it), false) }
        FxSlider("Saturation", fx.saturation, 0f..2f) { onChange(fx.copy(saturation = it), false) }
        FxSlider("Warmth", fx.warmth, -1f..1f) { onChange(fx.copy(warmth = it), false) }
        FxSlider("Vignette", fx.vignette, 0f..1f) { onChange(fx.copy(vignette = it), false) }
        Text("Motion", style = MaterialTheme.typography.labelSmall)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            MOTIONS.forEach { m -> Chip(nice(m), fx.motion == m) { onChange(fx.copy(motion = m), true) } }
        }
        if (fx.motion != "NONE") FxSlider("Motion amount", fx.motionAmt, 0f..1f) { onChange(fx.copy(motionAmt = it), false) }
        TextButton(onClick = { onChange(ClipFx(), true) }) { Text("Reset effects") }
    }
}

@Composable
fun LayerFxControls(fx: LayerFx, onChange: (LayerFx, Boolean) -> Unit) {
    Text("Effects", style = MaterialTheme.typography.labelMedium)
    FxSlider("Shadow", fx.shadow, 0f..1f) { onChange(fx.copy(shadow = it), false) }
    FxSlider("Glow", fx.glow, 0f..1f) { onChange(fx.copy(glow = it), false) }
    if (fx.glow > 0.01f) ColorRow(fx.glowColor) { onChange(fx.copy(glowColor = it), true) }
    FxSlider("Blur", fx.blur, 0f..1f) { onChange(fx.copy(blur = it), false) }
    FxSlider("Brightness", fx.brightness, -0.5f..0.5f) { onChange(fx.copy(brightness = it), false) }
    FxSlider("Contrast", fx.contrast, 0.5f..1.8f) { onChange(fx.copy(contrast = it), false) }
    FxSlider("Saturation", fx.saturation, 0f..2f) { onChange(fx.copy(saturation = it), false) }
    TextButton(onClick = { onChange(LayerFx(), true) }) { Text("Reset effects") }
}
