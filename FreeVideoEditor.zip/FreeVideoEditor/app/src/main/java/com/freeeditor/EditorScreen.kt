package com.freeeditor

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.media.MediaRecorder
import android.os.Build
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.util.LruCache
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.SeekParameters
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID
import kotlin.math.ceil
import kotlin.math.roundToInt

private fun fmt(ms: Long): String { val s = ms / 1000; return "%d:%02d.%d".format(s / 60, s % 60, (ms % 1000) / 100) }
private fun fmtShort(s: Int): String = "%d:%02d".format(s / 60, s % 60)

// ---------- Thumbnails ----------
private object ThumbCache {
    val cache = object : LruCache<String, Bitmap>(30 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }
}

@Composable
private fun ClipThumbs(clip: Clip, widthDp: Dp) {
    val ctx = LocalContext.current
    val n = ceil(widthDp.value / 56f).toInt().coerceIn(1, 24)
    val bitmaps = remember(clip.id, clip.inMs, clip.outMs, n) {
        mutableStateListOf<Bitmap?>().apply { repeat(n) { add(null) } }
    }
    LaunchedEffect(clip.id, clip.inMs, clip.outMs, n) {
        withContext(Dispatchers.IO) {
            val r = MediaMetadataRetriever()
            try {
                r.setDataSource(ctx, Uri.parse(clip.uri))
                for (i in 0 until n) {
                    val t = clip.inMs + ((i + 0.5) * clip.durationMs / n).toLong()
                    val key = "${clip.uri}@${t / 250}"
                    var b = ThumbCache.cache.get(key)
                    if (b == null) {
                        val f = r.getFrameAtTime(t * 1000, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                        if (f != null) {
                            b = Bitmap.createScaledBitmap(f, (f.width * 120f / f.height).toInt().coerceAtLeast(1), 120, true)
                            ThumbCache.cache.put(key, b)
                        }
                    }
                    bitmaps[i] = b
                }
            } catch (_: Exception) {
            } finally { r.release() }
        }
    }
    Row(Modifier.fillMaxSize()) {
        bitmaps.forEach { b ->
            Box(Modifier.weight(1f).fillMaxHeight()) {
                if (b != null) Image(b.asImageBitmap(), null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
            }
        }
    }
}

// ---------- Time ruler ----------
@Composable
private fun Ruler(totalMs: Long, zoom: Float) {
    val steps = listOf(1, 2, 5, 10, 30, 60, 300, 600)
    val interval = steps.firstOrNull { it * zoom >= 56f } ?: 600
    val tick = Color(0x66FFFFFF)
    Box(
        Modifier.width((totalMs / 1000f * zoom).dp).height(20.dp).clipToBounds().drawBehind {
            var s = 0
            while (s * 1000L <= totalMs) {
                val x = s * zoom * density
                drawLine(tick, Offset(x, size.height * 0.6f), Offset(x, size.height), 2f)
                s += interval
            }
        }
    ) {
        var s = 0
        while (s * 1000L <= totalMs) {
            Text(fmtShort(s), Modifier.offset(x = (s * zoom).dp + 3.dp), maxLines = 1, softWrap = false,
                style = MaterialTheme.typography.labelSmall, color = Color(0x99FFFFFF))
            s += interval
        }
    }
}

// ---------- Toolbar button ----------
@Composable
private fun ToolBtn(icon: ImageVector, label: String, enabled: Boolean = true, onClick: () -> Unit) {
    Column(
        Modifier.clip(RoundedCornerShape(12.dp)).clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 6.dp).alpha(if (enabled) 1f else 0.35f),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(icon, label)
        Text(label, style = MaterialTheme.typography.labelSmall, maxLines = 1)
    }
}


private data class Snap(val clips: List<Clip>, val texts: List<TextItem>, val audios: List<AudioClip>)

@Composable
private fun Chip(label: String, selected: Boolean, onClick: () -> Unit) {
    FilterChip(selected = selected, onClick = onClick, label = { Text(label) })
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TextPanel(t: TextItem, total: Long, onUpdate: (TextItem, Boolean) -> Unit) {
    Column(Modifier.fillMaxWidth().heightIn(max = 230.dp).verticalScroll(rememberScrollState()).padding(horizontal = 12.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)) {
        OutlinedTextField(value = t.text, onValueChange = { onUpdate(t.copy(text = it), false) },
            modifier = Modifier.fillMaxWidth(), label = { Text("Text") })
        Text("Presets", style = MaterialTheme.typography.labelSmall)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            PRESETS.forEach { p -> Chip(p, false) { onUpdate(applyPreset(t, p), true) } }
        }
        Text("Font", style = MaterialTheme.typography.labelSmall)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            FONTS.forEach { f -> Chip(f.lowercase().replaceFirstChar { it.uppercase() }, t.font == f) { onUpdate(t.copy(font = f), true) } }
            Chip("Bold", t.bold) { onUpdate(t.copy(bold = !t.bold), true) }
            Chip("Italic", t.italic) { onUpdate(t.copy(italic = !t.italic), true) }
        }
        Text("Size", style = MaterialTheme.typography.labelSmall)
        Slider(value = t.size, onValueChange = { onUpdate(t.copy(size = it), false) }, valueRange = 0.02f..0.2f)
        Text("Color", style = MaterialTheme.typography.labelSmall)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            PALETTE.forEach { c ->
                Box(Modifier.size(30.dp).clip(CircleShape).background(Color(c))
                    .border(if (c == t.color) 3.dp else 1.dp, if (c == t.color) MaterialTheme.colorScheme.primary else Color.Gray, CircleShape)
                    .clickable { onUpdate(t.copy(color = c), true) })
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Chip("Outline", t.outline) { onUpdate(t.copy(outline = !t.outline), true) }
            Chip("Shadow", t.shadow) { onUpdate(t.copy(shadow = !t.shadow), true) }
        }
        Text("Animation in", style = MaterialTheme.typography.labelSmall)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            ANIMS.forEach { a -> Chip(a.lowercase().replaceFirstChar { it.uppercase() }, t.animIn == a) { onUpdate(t.copy(animIn = a), true) } }
        }
        Text("Animation out", style = MaterialTheme.typography.labelSmall)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            ANIMS.forEach { a -> Chip(a.lowercase().replaceFirstChar { it.uppercase() }, t.animOut == a) { onUpdate(t.copy(animOut = a), true) } }
        }
        if (total > 0) {
            val st = t.startMs.coerceIn(0, total)
            val en = (t.startMs + t.durationMs).coerceIn(st, total)
            var range by remember(t.id, t.startMs, t.durationMs) { mutableStateOf(st.toFloat()..en.toFloat()) }
            Text("Timing: ${fmt(range.start.toLong())} - ${fmt(range.endInclusive.toLong())}", style = MaterialTheme.typography.labelSmall)
            RangeSlider(value = range, onValueChange = { range = it }, valueRange = 0f..total.toFloat(),
                onValueChangeFinished = {
                    val a = range.start.toLong(); val b = range.endInclusive.toLong()
                    if (b - a >= 300) onUpdate(t.copy(startMs = a, durationMs = b - a), true)
                })
        }
        Spacer(Modifier.height(6.dp))
    }
}


@Composable
private fun TimeLabel(playhead: () -> Long, total: Long, modifier: Modifier) {
    Text("${fmt(playhead())} / ${fmt(total)}", modifier, style = MaterialTheme.typography.bodySmall)
}

private fun assignLanes(audios: List<AudioClip>): Pair<Map<String, Int>, Int> {
    val ends = mutableListOf<Long>(); val map = HashMap<String, Int>()
    audios.sortedBy { it.startMs }.forEach { c ->
        var l = ends.indexOfFirst { it <= c.startMs }
        if (l < 0) { ends.add(c.endMs); l = ends.lastIndex } else ends[l] = c.endMs
        map[c.id] = l
    }
    return map to ends.size
}

@Composable
private fun AudioBar(a: AudioClip, zoom: Float, sel: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val ctx = LocalContext.current
    val peaks by produceState<FloatArray?>(null, a.uri) { value = withContext(Dispatchers.Default) { Waveform.load(ctx, a.uri) } }
    Box(
        modifier.width((a.durationMs / 1000f * zoom).dp).height(30.dp).padding(horizontal = 1.dp)
            .clip(RoundedCornerShape(5.dp)).background(if (sel) Color(0xFF2E7D6B) else Color(0xFF1F4D45))
            .then(if (sel) Modifier.border(2.dp, Color(0xFF7FE3C8), RoundedCornerShape(5.dp)) else Modifier)
            .clickable(onClick = onClick)
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val p = peaks ?: return@Canvas
            if (p.isEmpty()) return@Canvas
            val bars = (size.width / 4f).toInt().coerceAtLeast(1)
            for (i in 0 until bars) {
                val tMs = a.inMs + (i + 0.5f) / bars * a.durationMs
                val idx = (tMs / 1000f * Waveform.PPS).toInt().coerceIn(0, p.size - 1)
                val hh = (p[idx] * size.height).coerceAtLeast(1.5f)
                drawLine(Color(0xFF7FE3C8), Offset(i * 4f + 1f, (size.height - hh) / 2), Offset(i * 4f + 1f, (size.height + hh) / 2), 2.5f)
            }
        }
        Text(a.name, Modifier.padding(horizontal = 4.dp), maxLines = 1, softWrap = false,
            style = MaterialTheme.typography.labelSmall, color = Color.White)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AudioPanel(a: AudioClip, total: Long, onUpdate: (AudioClip, Boolean) -> Unit) {
    Column(Modifier.fillMaxWidth().heightIn(max = 230.dp).verticalScroll(rememberScrollState()).padding(horizontal = 12.dp)) {
        Text(a.name, style = MaterialTheme.typography.titleSmall, maxLines = 1)
        Text("Volume ${(a.volume * 100).toInt()}%", style = MaterialTheme.typography.labelSmall)
        Slider(value = a.volume, onValueChange = { onUpdate(a.copy(volume = it), false) }, valueRange = 0f..1f)
        val maxFade = maxOf(minOf(3000L, a.durationMs / 2), 100L).toFloat()
        Text("Fade in ${"%.1f".format(a.fadeInMs / 1000f)}s", style = MaterialTheme.typography.labelSmall)
        Slider(value = a.fadeInMs.toFloat().coerceIn(0f, maxFade), onValueChange = { onUpdate(a.copy(fadeInMs = it.toLong()), false) }, valueRange = 0f..maxFade)
        Text("Fade out ${"%.1f".format(a.fadeOutMs / 1000f)}s", style = MaterialTheme.typography.labelSmall)
        Slider(value = a.fadeOutMs.toFloat().coerceIn(0f, maxFade), onValueChange = { onUpdate(a.copy(fadeOutMs = it.toLong()), false) }, valueRange = 0f..maxFade)
        val maxStart = maxOf((total - a.durationMs).toFloat(), 1f)
        Text("Start at ${fmt(a.startMs)}", style = MaterialTheme.typography.labelSmall)
        Slider(value = a.startMs.toFloat().coerceIn(0f, maxStart), onValueChange = { onUpdate(a.copy(startMs = it.toLong()), false) }, valueRange = 0f..maxStart)
        var range by remember(a.id, a.inMs, a.outMs) { mutableStateOf(a.inMs.toFloat()..a.outMs.toFloat()) }
        Text("Trim ${fmt(range.start.toLong())} - ${fmt(range.endInclusive.toLong())}", style = MaterialTheme.typography.labelSmall)
        RangeSlider(value = range, onValueChange = { range = it }, valueRange = 0f..a.sourceMs.toFloat(),
            onValueChangeFinished = {
                val x = range.start.toLong(); val y = range.endInclusive.toLong()
                if (y - x >= 200) onUpdate(a.copy(inMs = x, outMs = y), true)
            })
        Spacer(Modifier.height(6.dp))
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditorScreen(initial: Project, onChange: (Project) -> Unit, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val density = LocalDensity.current
    val screenW = LocalConfiguration.current.screenWidthDp
    val scope = rememberCoroutineScope()
    var project by remember { mutableStateOf(initial) }
    val undo = remember { mutableStateListOf<Snap>() }
    val redo = remember { mutableStateListOf<Snap>() }
    var selectedId by remember { mutableStateOf<String?>(null) }
    var selectedTextId by remember { mutableStateOf<String?>(null) }
    var selectedAudioId by remember { mutableStateOf<String?>(null) }
    var playheadMs by remember { mutableStateOf(0L) }
    var zoom by remember { mutableStateOf(60f) } // dp per second
    var exportProgress by remember { mutableStateOf<Int?>(null) }
    var importing by remember { mutableStateOf(false) }
    var recorder by remember { mutableStateOf<MediaRecorder?>(null) }
    var recFile by remember { mutableStateOf<File?>(null) }
    var recStart by remember { mutableStateOf(0L) }
    var recElapsed by remember { mutableStateOf(0L) }
    val exporter = remember { Exporter(ctx) }
    val scroll = rememberScrollState()

    val player = remember { ExoPlayer.Builder(ctx).build() }
    val audioPreview = remember { AudioPreview(ctx) }
    DisposableEffect(Unit) {
        onDispose {
            exporter.cancel(); player.release(); audioPreview.release()
            runCatching { recorder?.stop() }; recorder?.release()
        }
    }

    fun commit(clips: List<Clip> = project.clips, texts: List<TextItem> = project.texts,
               audios: List<AudioClip> = project.audios, record: Boolean = true) {
        if (record) { undo.add(Snap(project.clips, project.texts, project.audios)); redo.clear() }
        project = project.copy(clips = clips, texts = texts, audios = audios); onChange(project)
    }
    fun toast(m: String) = Toast.makeText(ctx, m, Toast.LENGTH_SHORT).show()
    fun clearSel() { selectedId = null; selectedTextId = null; selectedAudioId = null }

    val total = project.clips.sumOf { it.durationMs }
    val (outW, outH) = outputSize(project.clips)

    // Keep the preview in sync with the project model.
    LaunchedEffect(project.clips) {
        val idx = player.currentMediaItemIndex; val pos = player.currentPosition
        if (project.clips.isEmpty()) { player.clearMediaItems(); return@LaunchedEffect }
        player.setMediaItems(project.clips.map {
            MediaItem.Builder().setUri(Uri.parse(it.uri)).setClippingConfiguration(
                MediaItem.ClippingConfiguration.Builder()
                    .setStartPositionMs(it.inMs).setEndPositionMs(it.outMs).build()).build()
        })
        player.prepare()
        player.seekTo(idx.coerceIn(0, project.clips.size - 1), pos)
    }

    fun seekGlobal(ms: Long) {
        var acc = 0L
        val clips = project.clips
        clips.forEachIndexed { i, c ->
            if (ms < acc + c.durationMs || i == clips.lastIndex) {
                player.seekTo(i, (ms - acc).coerceIn(0, c.durationMs)); return
            }
            acc += c.durationMs
        }
    }

    // One loop, locked to the display frame rate. Only tiny composables read playheadMs,
    // so the timeline itself is not recomposed while playing.
    LaunchedEffect(Unit) {
        var scrubbing = false; var tick = 0
        while (true) {
            withFrameNanos { }
            val clips = project.clips
            if (clips.isNotEmpty()) {
                val t = clips.sumOf { it.durationMs }
                val pxPerMs = zoom * density.density / 1000f
                if (scroll.isScrollInProgress) {
                    if (!scrubbing) { scrubbing = true; player.setSeekParameters(SeekParameters.CLOSEST_SYNC) }
                    if (player.isPlaying) player.pause()
                    val ms = (scroll.value / pxPerMs).toLong().coerceIn(0, t)
                    if (ms != playheadMs) { seekGlobal(ms); playheadMs = ms }
                } else {
                    if (scrubbing) { scrubbing = false; player.setSeekParameters(SeekParameters.EXACT) }
                    val i = player.currentMediaItemIndex.coerceIn(0, clips.size - 1)
                    var acc = 0L
                    for (k in 0 until i) acc += clips[k].durationMs
                    playheadMs = acc + player.currentPosition.coerceAtLeast(0)
                    val diff = (playheadMs * pxPerMs).roundToInt() - scroll.value
                    if (diff != 0) scroll.dispatchRawDelta(diff.toFloat())
                    player.volume = clips[i].volume
                }
            } else playheadMs = 0
            if (++tick % 3 == 0) audioPreview.sync(project.audios, playheadMs, player.isPlaying && !scroll.isScrollInProgress)
        }
    }
    LaunchedEffect(recorder) {
        val t0 = System.currentTimeMillis()
        while (recorder != null) { recElapsed = System.currentTimeMillis() - t0; delay(200) }
    }

    // Gallery (system photo picker): photos and videos, no storage permission needed.
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickMultipleVisualMedia()) { uris ->
        if (uris.isNotEmpty()) scope.launch {
            importing = true
            val added = mutableListOf<Clip>()
            for (u in uris) Importer.import(ctx, u)?.let { added.add(it) }
            importing = false
            if (added.size < uris.size) toast("Some items could not be imported")
            if (added.isNotEmpty()) commit(clips = project.clips + added)
        }
    }
    // Music / sound effects from files (the gallery has no audio).
    val audioPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) scope.launch {
            importing = true
            val added = mutableListOf<AudioClip>()
            var start = playheadMs
            for (u in uris) {
                var a = Importer.importAudio(ctx, u, start) ?: continue
                if (total > 0 && a.endMs > total) a = a.copy(outMs = a.inMs + maxOf(total - start, 500L))
                added.add(a); start = a.endMs
            }
            importing = false
            if (added.size < uris.size) toast("Some audio files could not be imported")
            if (added.isNotEmpty()) { commit(audios = project.audios + added); clearSel(); selectedAudioId = added.first().id }
        }
    }

    fun startRecording() {
        val f = File(File(ctx.filesDir, "media").apply { mkdirs() }, "rec_${UUID.randomUUID().toString().take(8)}.m4a")
        try {
            @Suppress("DEPRECATION")
            val r = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(ctx) else MediaRecorder()
            r.setAudioSource(MediaRecorder.AudioSource.MIC)
            r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            r.setAudioSamplingRate(44100); r.setAudioEncodingBitRate(128000)
            r.setOutputFile(f.absolutePath)
            r.prepare(); r.start()
            recFile = f; recStart = playheadMs; recorder = r
            if (total > 0) player.play()
        } catch (e: Exception) { toast("Could not start recording: ${e.message}") }
    }
    fun stopRecording() {
        val r = recorder ?: return
        recorder = null; player.pause()
        runCatching { r.stop() }; r.release()
        val f = recFile ?: return
        val p = Importer.probe(ctx, Uri.fromFile(f))
        if (p != null && p.durationMs > 300) {
            val a = AudioClip(uri = Uri.fromFile(f).toString(), name = "Voice", startMs = recStart, inMs = 0, outMs = p.durationMs, sourceMs = p.durationMs)
            commit(audios = project.audios + a); clearSel(); selectedAudioId = a.id
        } else { f.delete(); toast("Recording too short") }
    }
    val micPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) startRecording() else toast("Microphone permission is needed to record")
    }

    val selected = project.clips.find { it.id == selectedId }
    val selText = project.texts.find { it.id == selectedTextId }
    val selAudio = project.audios.find { it.id == selectedAudioId }

    fun split() {
        var acc = 0L
        for (c in project.clips) {
            val off = playheadMs - acc
            if (off in 200 until c.durationMs - 200) {
                val a = c.copy(outMs = c.inMs + off)
                val b = c.copy(id = UUID.randomUUID().toString(), inMs = c.inMs + off)
                commit(clips = project.clips.flatMap { if (it.id == c.id) listOf(a, b) else listOf(it) }); return
            }
            acc += c.durationMs
        }
    }
    fun splitAudio(a: AudioClip) {
        val off = playheadMs - a.startMs
        if (off !in 200 until a.durationMs - 200) { toast("Move the playhead inside the audio clip"); return }
        val a1 = a.copy(outMs = a.inMs + off, fadeOutMs = 0)
        val a2 = a.copy(id = UUID.randomUUID().toString(), startMs = playheadMs, inMs = a.inMs + off, fadeInMs = 0)
        commit(audios = project.audios.flatMap { if (it.id == a.id) listOf(a1, a2) else listOf(it) })
    }
    fun extractAudio(c: Clip) {
        if (!Importer.hasAudio(ctx, Uri.parse(c.uri))) { toast("This clip has no audio"); return }
        var start = 0L
        for (x in project.clips) { if (x.id == c.id) break; start += x.durationMs }
        val a = AudioClip(uri = c.uri, name = "Extracted audio", startMs = start, inMs = c.inMs, outMs = c.outMs, sourceMs = c.sourceMs)
        commit(clips = project.clips.map { if (it.id == c.id) it.copy(volume = 0f) else it }, audios = project.audios + a)
        clearSel(); selectedAudioId = a.id
    }
    fun boundaries(): List<Long> {
        val l = mutableListOf(0L); var acc = 0L
        project.clips.forEach { acc += it.durationMs; l.add(acc) }
        return l
    }
    fun addText() {
        if (total <= 0) { toast("Import a video or photo first"); return }
        val start = playheadMs.coerceAtMost(maxOf(total - 500, 0))
        val dur = minOf(3000L, total - start).coerceAtLeast(500)
        val t = TextItem(startMs = start, durationMs = dur)
        commit(texts = project.texts + t)
        clearSel(); selectedTextId = t.id
    }
    fun updateText(nt: TextItem, record: Boolean) {
        commit(texts = project.texts.map { if (it.id == nt.id) nt else it }, record = record)
    }
    fun updateAudio(na: AudioClip, record: Boolean) {
        commit(audios = project.audios.map { if (it.id == na.id) na else it }, record = record)
    }

    val (lanes, laneCount) = remember(project.audios) { assignLanes(project.audios) }
    val span = maxOf(total, project.audios.maxOfOrNull { it.endMs } ?: 0L)

    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") }
            Text(project.name, Modifier.weight(1f), style = MaterialTheme.typography.titleMedium)
            if (recorder != null) Text("REC ${fmtShort((recElapsed / 1000).toInt())}  ", color = Color(0xFFFF3B30), style = MaterialTheme.typography.labelLarge)
            Button(enabled = project.clips.isNotEmpty() && exportProgress == null && !importing && recorder == null, onClick = {
                exportProgress = 0
                val out = File(ctx.getExternalFilesDir(android.os.Environment.DIRECTORY_MOVIES), "export_${UUID.randomUUID().toString().take(6)}.mp4")
                exporter.start(project, out, { exportProgress = it }) { res ->
                    exportProgress = null
                    res.onSuccess { Toast.makeText(ctx, "Saved: ${it.absolutePath}", Toast.LENGTH_LONG).show() }
                    res.onFailure { Toast.makeText(ctx, "Export failed: ${it.message}", Toast.LENGTH_LONG).show() }
                }
            }) { Text("Export") }
            Spacer(Modifier.width(8.dp))
        }
        if (importing) {
            Row(Modifier.padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                LinearProgressIndicator(modifier = Modifier.weight(1f))
                Text("  Importing...", style = MaterialTheme.typography.labelSmall)
            }
        }
        exportProgress?.let {
            Row(Modifier.padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                LinearProgressIndicator(progress = { it / 100f }, modifier = Modifier.weight(1f))
                TextButton(onClick = { exporter.cancel(); exportProgress = null }) { Text("Cancel") }
            }
        }

        // Preview: frame has the export aspect ratio; text is drawn by the same renderer as the exporter.
        Box(Modifier.fillMaxWidth().weight(1f).background(Color.Black), contentAlignment = Alignment.Center) {
            Box(Modifier.aspectRatio(outW / outH.toFloat())) {
                AndroidView(factory = { PlayerView(it).apply { this.player = player; useController = false } }, modifier = Modifier.fillMaxSize())
                Canvas(
                    Modifier.fillMaxSize().pointerInput(selectedTextId) {
                        detectDragGestures(
                            onDragStart = { undo.add(Snap(project.clips, project.texts, project.audios)); redo.clear() },
                            onDragEnd = { onChange(project) },
                            onDrag = { change, d ->
                                change.consume()
                                val sid = selectedTextId
                                if (sid != null) project = project.copy(texts = project.texts.map {
                                    if (it.id == sid) it.copy(
                                        x = (it.x + d.x / size.width).coerceIn(0f, 1f),
                                        y = (it.y + d.y / size.height).coerceIn(0f, 1f)) else it
                                })
                            })
                    }
                ) {
                    val ms = playheadMs
                    drawIntoCanvas { TextRender.draw(it.nativeCanvas, size.width.toInt(), size.height.toInt(), project.texts, ms) }
                }
            }
            if (project.clips.isEmpty()) Text("Tap Import to add photos or videos", Modifier.align(Alignment.Center))
        }

        // Transport controls
        var playing by remember { mutableStateOf(false) }
        DisposableEffect(player) {
            val l = object : androidx.media3.common.Player.Listener {
                override fun onIsPlayingChanged(isPlaying: Boolean) { playing = isPlaying }
            }
            player.addListener(l); onDispose { player.removeListener(l) }
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            TimeLabel({ playheadMs }, total, Modifier.weight(1f))
            IconButton(onClick = { val p = boundaries().lastOrNull { it < playheadMs - 300 } ?: 0L; seekGlobal(p) }) { Icon(Icons.Default.SkipPrevious, "Previous cut") }
            IconButton(onClick = { if (playing) player.pause() else player.play() }) {
                Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, "Play/Pause")
            }
            IconButton(onClick = { val n = boundaries().firstOrNull { it > playheadMs + 300 } ?: total; seekGlobal(n) }) { Icon(Icons.Default.SkipNext, "Next cut") }
            Spacer(Modifier.weight(1f))
        }

        // Timeline: ruler, video thumbnails, text track, audio lanes; fixed center playhead; pinch to zoom
        val halfW = (screenW / 2).dp
        Box(
            Modifier.fillMaxWidth().height((118 + laneCount * 34).dp).pointerInput(Unit) {
                awaitEachGesture {
                    awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
                    do {
                        val event = awaitPointerEvent(PointerEventPass.Initial)
                        if (event.changes.size >= 2) {
                            val z = event.calculateZoom()
                            if (z != 1f) {
                                zoom = (zoom * z).coerceIn(10f, 200f)
                                event.changes.forEach { it.consume() }
                            }
                        }
                    } while (event.changes.any { it.pressed })
                }
            }
        ) {
            Row(Modifier.fillMaxSize().horizontalScroll(scroll)) {
                Spacer(Modifier.width(halfW))
                Column {
                    Ruler(total, zoom)
                    Row {
                        project.clips.forEach { c ->
                            val w = (c.durationMs / 1000f * zoom).dp
                            val sel = c.id == selectedId
                            Box(
                                Modifier.width(w).height(64.dp).padding(horizontal = 1.dp)
                                    .clip(RoundedCornerShape(6.dp)).background(MaterialTheme.colorScheme.surface)
                                    .then(if (sel) Modifier.border(2.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(6.dp)) else Modifier)
                                    .clickable { val was = sel; clearSel(); if (!was) selectedId = c.id }
                            ) {
                                ClipThumbs(c, w)
                                Text(fmt(c.durationMs), Modifier.align(Alignment.BottomStart).background(Color(0x99000000)).padding(horizontal = 4.dp),
                                    style = MaterialTheme.typography.labelSmall)
                                if (c.volume == 0f) Icon(Icons.Default.VolumeOff, null, Modifier.align(Alignment.TopEnd).size(16.dp).padding(2.dp))
                            }
                        }
                    }
                    // Text track
                    Box(Modifier.width((total / 1000f * zoom).dp).height(30.dp).padding(top = 4.dp)) {
                        project.texts.forEach { tx ->
                            val sel = tx.id == selectedTextId
                            Box(
                                Modifier.offset(x = (tx.startMs / 1000f * zoom).dp).width((tx.durationMs / 1000f * zoom).dp)
                                    .fillMaxHeight().padding(horizontal = 1.dp).clip(RoundedCornerShape(5.dp))
                                    .background(if (sel) MaterialTheme.colorScheme.primary else Color(0xFF3A6EA5))
                                    .clickable { val was = sel; clearSel(); if (!was) selectedTextId = tx.id }
                            ) {
                                Text(tx.text, Modifier.padding(horizontal = 4.dp), maxLines = 1, softWrap = false,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (sel) Color.Black else Color.White)
                            }
                        }
                    }
                    // Audio lanes with waveforms
                    if (laneCount > 0) {
                        Box(Modifier.width((span / 1000f * zoom).dp).height((laneCount * 34).dp).padding(top = 4.dp)) {
                            project.audios.forEach { a ->
                                val sel = a.id == selectedAudioId
                                AudioBar(a, zoom, sel, Modifier.offset(x = (a.startMs / 1000f * zoom).dp, y = ((lanes[a.id] ?: 0) * 34).dp)) {
                                    val was = sel; clearSel(); if (!was) selectedAudioId = a.id
                                }
                            }
                        }
                    }
                }
                Spacer(Modifier.width(halfW))
            }
            Box(Modifier.align(Alignment.TopCenter).width(2.dp).fillMaxHeight().background(Color.White))
        }

        if (selText != null) {
            TextPanel(selText, total) { nt, rec -> updateText(nt, rec) }
        } else if (selAudio != null) {
            AudioPanel(selAudio, total) { na, rec -> updateAudio(na, rec) }
        } else selected?.let { c ->
            var range by remember(c.id, c.inMs, c.outMs) { mutableStateOf(c.inMs.toFloat()..c.outMs.toFloat()) }
            Column(Modifier.padding(horizontal = 16.dp)) {
                Text("Trim: ${fmt(range.start.toLong())} – ${fmt(range.endInclusive.toLong())}", style = MaterialTheme.typography.labelSmall)
                RangeSlider(value = range, onValueChange = { range = it }, valueRange = 0f..c.sourceMs.toFloat(),
                    onValueChangeFinished = {
                        val a = range.start.toLong(); val b = range.endInclusive.toLong()
                        if (b - a >= 200) commit(clips = project.clips.map { if (it.id == c.id) it.copy(inMs = a, outMs = b) else it })
                    })
                Text("Volume ${(c.volume * 100).toInt()}%", style = MaterialTheme.typography.labelSmall)
                Slider(value = c.volume, onValueChange = { v -> commit(clips = project.clips.map { if (it.id == c.id) it.copy(volume = v) else it }, record = false) },
                    valueRange = 0f..1f)
            }
        }

        // Contextual bottom toolbar
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(vertical = 4.dp)) {
            if (selText != null) {
                ToolBtn(Icons.Default.Close, "Done") { clearSel() }
                ToolBtn(Icons.Default.ContentCopy, "Duplicate") {
                    val copy = selText.copy(id = UUID.randomUUID().toString(), y = (selText.y + 0.08f).coerceAtMost(0.95f))
                    commit(texts = project.texts + copy); clearSel(); selectedTextId = copy.id
                }
                ToolBtn(Icons.Default.Delete, "Delete") { commit(texts = project.texts.filter { it.id != selText.id }); clearSel() }
            } else if (selAudio != null) {
                ToolBtn(Icons.Default.Close, "Done") { clearSel() }
                ToolBtn(Icons.Default.ContentCut, "Split") { splitAudio(selAudio) }
                ToolBtn(Icons.Default.ContentCopy, "Duplicate") {
                    val copy = selAudio.copy(id = UUID.randomUUID().toString(), startMs = selAudio.endMs)
                    commit(audios = project.audios + copy); clearSel(); selectedAudioId = copy.id
                }
                ToolBtn(Icons.Default.Delete, "Delete") { commit(audios = project.audios.filter { it.id != selAudio.id }); clearSel() }
            } else if (selected == null) {
                ToolBtn(Icons.Default.Add, "Import") { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageAndVideo)) }
                ToolBtn(Icons.Default.TextFields, "Text") { addText() }
                ToolBtn(Icons.Default.MusicNote, "Music") { audioPicker.launch(arrayOf("audio/*")) }
                ToolBtn(if (recorder != null) Icons.Default.Stop else Icons.Default.Mic, if (recorder != null) "Stop" else "Record") {
                    if (recorder != null) stopRecording()
                    else if (ctx.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) startRecording()
                    else micPermission.launch(Manifest.permission.RECORD_AUDIO)
                }
                ToolBtn(Icons.Default.ContentCut, "Split") { split() }
                ToolBtn(Icons.Default.Undo, "Undo", undo.isNotEmpty()) {
                    val s = undo.removeAt(undo.lastIndex)
                    redo.add(Snap(project.clips, project.texts, project.audios))
                    project = project.copy(clips = s.clips, texts = s.texts, audios = s.audios); onChange(project)
                }
                ToolBtn(Icons.Default.Redo, "Redo", redo.isNotEmpty()) {
                    val s = redo.removeAt(redo.lastIndex)
                    undo.add(Snap(project.clips, project.texts, project.audios))
                    project = project.copy(clips = s.clips, texts = s.texts, audios = s.audios); onChange(project)
                }
                ToolBtn(Icons.Default.ZoomOutMap, "Fit", total > 0) {
                    zoom = (screenW * 0.9f / (total / 1000f)).coerceIn(10f, 200f)
                }
            } else {
                ToolBtn(Icons.Default.Close, "Done") { clearSel() }
                ToolBtn(Icons.Default.ContentCut, "Split") { split() }
                ToolBtn(Icons.Default.GraphicEq, "Extract audio") { extractAudio(selected) }
                ToolBtn(Icons.Default.ContentCopy, "Duplicate") {
                    commit(clips = project.clips.flatMap { if (it.id == selected.id) listOf(it, it.copy(id = UUID.randomUUID().toString())) else listOf(it) })
                }
                ToolBtn(Icons.Default.Delete, "Delete") { commit(clips = project.clips.filter { it.id != selected.id }); clearSel() }
                val idx = project.clips.indexOf(selected)
                ToolBtn(Icons.Default.ArrowBack, "Earlier", idx > 0) {
                    val l = project.clips.toMutableList(); l.removeAt(idx); l.add(idx - 1, selected); commit(clips = l)
                }
                ToolBtn(Icons.Default.ArrowForward, "Later", idx < project.clips.lastIndex) {
                    val l = project.clips.toMutableList(); l.removeAt(idx); l.add(idx + 1, selected); commit(clips = l)
                }
            }
        }
    }
}
