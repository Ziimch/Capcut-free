package com.freeeditor

import android.content.Intent
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.util.LruCache
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID
import kotlin.math.ceil
import kotlin.math.roundToInt

private fun fmt(ms: Long): String { val s = ms / 1000; return "%d:%02d.%d".format(s / 60, s % 60, (ms % 1000) / 100) }
private fun fmtShort(s: Int): String = "%d:%02d".format(s / 60, s % 60)

private fun probeDurationMs(ctx: android.content.Context, uri: Uri): Long = runCatching {
    val r = MediaMetadataRetriever()
    r.setDataSource(ctx, uri)
    val d = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLong() ?: 0L
    r.release(); d
}.getOrDefault(0L)

// ---------- Thumbnails ----------
private object ThumbCache {
    val cache = object : LruCache<String, Bitmap>(30 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }
}

@Composable
private fun ClipThumbs(clip: Clip, widthDp: Dp) {
    val ctx = LocalContext.current
    val n = ceil(widthDp.value / 56f).toInt().coerceIn(1, 24)
    val bitmaps = remember(clip.id, clip.inMs, clip.outMs, n) {
        mutableStateListOf<Bitmap?>().apply { repeat(n) { add(null) } }
    }
    LaunchedEffect(clip.id, clip.inMs, clip.outMs, n) {
        withContext(Dispatchers.IO) {
            val r = MediaMetadataRetriever()
            try {
                r.setDataSource(ctx, Uri.parse(clip.uri))
                for (i in 0 until n) {
                    val t = clip.inMs + ((i + 0.5) * clip.durationMs / n).toLong()
                    val key = "${clip.uri}@${t / 250}"
                    var b = ThumbCache.cache.get(key)
                    if (b == null) {
                        val f = r.getFrameAtTime(t * 1000, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                        if (f != null) {
                            b = Bitmap.createScaledBitmap(f, (f.width * 120f / f.height).toInt().coerceAtLeast(1), 120, true)
                            ThumbCache.cache.put(key, b)
                        }
                    }
                    bitmaps[i] = b
                }
            } catch (_: Exception) {
            } finally { r.release() }
        }
    }
    Row(Modifier.fillMaxSize()) {
        bitmaps.forEach { b ->
            Box(Modifier.weight(1f).fillMaxHeight()) {
                if (b != null) Image(b.asImageBitmap(), null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
            }
        }
    }
}

// ---------- Time ruler ----------
@Composable
private fun Ruler(totalMs: Long, zoom: Float) {
    val steps = listOf(1, 2, 5, 10, 30, 60, 300, 600)
    val interval = steps.firstOrNull { it * zoom >= 56f } ?: 600
    val tick = Color(0x66FFFFFF)
    Box(
        Modifier.width((totalMs / 1000f * zoom).dp).height(20.dp).clipToBounds().drawBehind {
            var s = 0
            while (s * 1000L <= totalMs) {
                val x = s * zoom * density
                drawLine(tick, Offset(x, size.height * 0.6f), Offset(x, size.height), 2f)
                s += interval
            }
        }
    ) {
        var s = 0
        while (s * 1000L <= totalMs) {
            Text(fmtShort(s), Modifier.offset(x = (s * zoom).dp + 3.dp), maxLines = 1, softWrap = false,
                style = MaterialTheme.typography.labelSmall, color = Color(0x99FFFFFF))
            s += interval
        }
    }
}

// ---------- Toolbar button ----------
@Composable
private fun ToolBtn(icon: ImageVector, label: String, enabled: Boolean = true, onClick: () -> Unit) {
    Column(
        Modifier.clip(RoundedCornerShape(12.dp)).clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 6.dp).alpha(if (enabled) 1f else 0.35f),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(icon, label)
        Text(label, style = MaterialTheme.typography.labelSmall, maxLines = 1)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditorScreen(initial: Project, onChange: (Project) -> Unit, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val density = LocalDensity.current
    val screenW = LocalConfiguration.current.screenWidthDp
    var project by remember { mutableStateOf(initial) }
    val undo = remember { mutableStateListOf<List<Clip>>() }
    val redo = remember { mutableStateListOf<List<Clip>>() }
    var selectedId by remember { mutableStateOf<String?>(null) }
    var playheadMs by remember { mutableStateOf(0L) }
    var zoom by remember { mutableStateOf(60f) } // dp per second
    var exportProgress by remember { mutableStateOf<Int?>(null) }
    val exporter = remember { Exporter(ctx) }
    val scroll = rememberScrollState()

    val player = remember { ExoPlayer.Builder(ctx).build() }
    DisposableEffect(Unit) { onDispose { exporter.cancel(); player.release() } }

    fun commit(clips: List<Clip>) {
        undo.add(project.clips); redo.clear()
        project = project.copy(clips = clips); onChange(project)
    }
    val total = project.clips.sumOf { it.durationMs }

    // Keep the preview in sync with the project model.
    LaunchedEffect(project.clips) {
        val idx = player.currentMediaItemIndex; val pos = player.currentPosition
        if (project.clips.isEmpty()) { player.clearMediaItems(); return@LaunchedEffect }
        player.setMediaItems(project.clips.map {
            MediaItem.Builder().setUri(Uri.parse(it.uri)).setClippingConfiguration(
                MediaItem.ClippingConfiguration.Builder()
                    .setStartPositionMs(it.inMs).setEndPositionMs(it.outMs).build()).build()
        })
        player.prepare()
        player.seekTo(idx.coerceIn(0, project.clips.size - 1), pos)
    }

    fun seekGlobal(ms: Long) {
        var acc = 0L
        val clips = project.clips
        clips.forEachIndexed { i, c ->
            if (ms < acc + c.durationMs || i == clips.lastIndex) {
                player.seekTo(i, (ms - acc).coerceIn(0, c.durationMs)); return
            }
            acc += c.durationMs
        }
    }

    // Playhead is fixed in the center; the timeline scrolls under it.
    LaunchedEffect(Unit) {
        while (true) {
            val clips = project.clips
            val t = clips.sumOf { it.durationMs }
            val pxPerMs = zoom * density.density / 1000f
            if (clips.isNotEmpty()) {
                if (scroll.isScrollInProgress) {
                    if (player.isPlaying) player.pause()
                    val ms = (scroll.value / pxPerMs).toLong().coerceIn(0, t)
                    if (ms != playheadMs) { seekGlobal(ms); playheadMs = ms }
                } else {
                    val i = player.currentMediaItemIndex.coerceIn(0, clips.size - 1)
                    playheadMs = clips.take(i).sumOf { it.durationMs } + player.currentPosition.coerceAtLeast(0)
                    val diff = (playheadMs * pxPerMs).roundToInt() - scroll.value
                    if (diff != 0) scroll.dispatchRawDelta(diff.toFloat())
                }
            } else playheadMs = 0
            delay(33)
        }
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        val added = uris.mapNotNull { u ->
            runCatching { ctx.contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            val d = probeDurationMs(ctx, u)
            if (d > 0) Clip(uri = u.toString(), inMs = 0, outMs = d, sourceMs = d) else null
        }
        if (added.isEmpty() && uris.isNotEmpty()) Toast.makeText(ctx, "Could not read that media", Toast.LENGTH_SHORT).show()
        else if (added.isNotEmpty()) commit(project.clips + added)
    }

    val selected = project.clips.find { it.id == selectedId }

    fun split() {
        var acc = 0L
        for (c in project.clips) {
            val off = playheadMs - acc
            if (off in 200 until c.durationMs - 200) {
                val a = c.copy(outMs = c.inMs + off)
                val b = c.copy(id = UUID.randomUUID().toString(), inMs = c.inMs + off)
                commit(project.clips.flatMap { if (it.id == c.id) listOf(a, b) else listOf(it) }); return
            }
            acc += c.durationMs
        }
    }
    fun boundaries(): List<Long> {
        val l = mutableListOf(0L); var acc = 0L
        project.clips.forEach { acc += it.durationMs; l.add(acc) }
        return l
    }

    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") }
            Text(project.name, Modifier.weight(1f), style = MaterialTheme.typography.titleMedium)
            Button(enabled = project.clips.isNotEmpty() && exportProgress == null, onClick = {
                exportProgress = 0
                val out = File(ctx.getExternalFilesDir(android.os.Environment.DIRECTORY_MOVIES), "export_${UUID.randomUUID().toString().take(6)}.mp4")
                exporter.start(project.clips, out, { exportProgress = it }) { res ->
                    exportProgress = null
                    res.onSuccess { Toast.makeText(ctx, "Saved: ${it.absolutePath}", Toast.LENGTH_LONG).show() }
                    res.onFailure { Toast.makeText(ctx, "Export failed: ${it.message}", Toast.LENGTH_LONG).show() }
                }
            }) { Text("Export") }
            Spacer(Modifier.width(8.dp))
        }
        exportProgress?.let {
            Row(Modifier.padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                LinearProgressIndicator(progress = { it / 100f }, modifier = Modifier.weight(1f))
                TextButton(onClick = { exporter.cancel(); exportProgress = null }) { Text("Cancel") }
            }
        }
        Box(Modifier.fillMaxWidth().weight(1f).background(Color.Black)) {
            AndroidView(factory = { PlayerView(it).apply { this.player = player; useController = false } }, modifier = Modifier.fillMaxSize())
            if (project.clips.isEmpty()) Text("Tap Import to add videos", Modifier.align(Alignment.Center))
        }

        // Transport controls
        var playing by remember { mutableStateOf(false) }
        DisposableEffect(player) {
            val l = object : androidx.media3.common.Player.Listener {
                override fun onIsPlayingChanged(isPlaying: Boolean) { playing = isPlaying }
            }
            player.addListener(l); onDispose { player.removeListener(l) }
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("${fmt(playheadMs)} / ${fmt(total)}", Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
            IconButton(onClick = { val p = boundaries().lastOrNull { it < playheadMs - 300 } ?: 0L; seekGlobal(p) }) { Icon(Icons.Default.SkipPrevious, "Previous cut") }
            IconButton(onClick = { if (playing) player.pause() else player.play() }) {
                Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, "Play/Pause")
            }
            IconButton(onClick = { val n = boundaries().firstOrNull { it > playheadMs + 300 } ?: total; seekGlobal(n) }) { Icon(Icons.Default.SkipNext, "Next cut") }
            Spacer(Modifier.weight(1f))
        }

        // Timeline: ruler + thumbnails, fixed center playhead, pinch to zoom
        val halfW = (screenW / 2).dp
        Box(
            Modifier.fillMaxWidth().height(100.dp).pointerInput(Unit) {
                awaitEachGesture {
                    awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
                    do {
                        val event = awaitPointerEvent(PointerEventPass.Initial)
                        if (event.changes.size >= 2) {
                            val z = event.calculateZoom()
                            if (z != 1f) {
                                zoom = (zoom * z).coerceIn(10f, 200f)
                                event.changes.forEach { it.consume() }
                            }
                        }
                    } while (event.changes.any { it.pressed })
                }
            }
        ) {
            Row(Modifier.fillMaxSize().horizontalScroll(scroll)) {
                Spacer(Modifier.width(halfW))
                Column {
                    Ruler(total, zoom)
                    Row {
                        project.clips.forEach { c ->
                            val w = (c.durationMs / 1000f * zoom).dp
                            val sel = c.id == selectedId
                            Box(
                                Modifier.width(w).height(64.dp).padding(horizontal = 1.dp)
                                    .clip(RoundedCornerShape(6.dp)).background(MaterialTheme.colorScheme.surface)
                                    .then(if (sel) Modifier.border(2.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(6.dp)) else Modifier)
                                    .clickable { selectedId = if (sel) null else c.id }
                            ) {
                                ClipThumbs(c, w)
                                Text(fmt(c.durationMs), Modifier.align(Alignment.BottomStart).background(Color(0x99000000)).padding(horizontal = 4.dp),
                                    style = MaterialTheme.typography.labelSmall)
                            }
                        }
                    }
                }
                Spacer(Modifier.width(halfW))
            }
            Box(Modifier.align(Alignment.TopCenter).width(2.dp).fillMaxHeight().background(Color.White))
        }

        selected?.let { c ->
            var range by remember(c.id, c.inMs, c.outMs) { mutableStateOf(c.inMs.toFloat()..c.outMs.toFloat()) }
            Column(Modifier.padding(horizontal = 16.dp)) {
                Text("Trim: ${fmt(range.start.toLong())} – ${fmt(range.endInclusive.toLong())}", style = MaterialTheme.typography.labelSmall)
                RangeSlider(value = range, onValueChange = { range = it }, valueRange = 0f..c.sourceMs.toFloat(),
                    onValueChangeFinished = {
                        val a = range.start.toLong(); val b = range.endInclusive.toLong()
                        if (b - a >= 200) commit(project.clips.map { if (it.id == c.id) it.copy(inMs = a, outMs = b) else it })
                    })
            }
        }

        // Contextual bottom toolbar
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(vertical = 4.dp)) {
            if (selected == null) {
                ToolBtn(Icons.Default.Add, "Import") { picker.launch(arrayOf("video/*")) }
                ToolBtn(Icons.Default.ContentCut, "Split") { split() }
                ToolBtn(Icons.Default.Undo, "Undo", undo.isNotEmpty()) {
                    redo.add(project.clips); project = project.copy(clips = undo.removeAt(undo.lastIndex)); onChange(project)
                }
                ToolBtn(Icons.Default.Redo, "Redo", redo.isNotEmpty()) {
                    undo.add(project.clips); project = project.copy(clips = redo.removeAt(redo.lastIndex)); onChange(project)
                }
                ToolBtn(Icons.Default.ZoomOutMap, "Fit", total > 0) {
                    zoom = (screenW * 0.9f / (total / 1000f)).coerceIn(10f, 200f)
                }
            } else {
                ToolBtn(Icons.Default.Close, "Done") { selectedId = null }
                ToolBtn(Icons.Default.ContentCut, "Split") { split() }
                ToolBtn(Icons.Default.ContentCopy, "Duplicate") {
                    commit(project.clips.flatMap { if (it.id == selected.id) listOf(it, it.copy(id = UUID.randomUUID().toString())) else listOf(it) })
                }
                ToolBtn(Icons.Default.Delete, "Delete") { commit(project.clips.filter { it.id != selected.id }); selectedId = null }
                val idx = project.clips.indexOf(selected)
                ToolBtn(Icons.Default.ArrowBack, "Earlier", idx > 0) {
                    val l = project.clips.toMutableList(); l.removeAt(idx); l.add(idx - 1, selected); commit(l)
                }
                ToolBtn(Icons.Default.ArrowForward, "Later", idx < project.clips.lastIndex) {
                    val l = project.clips.toMutableList(); l.removeAt(idx); l.add(idx + 1, selected); commit(l)
                }
            }
        }
    }
}
