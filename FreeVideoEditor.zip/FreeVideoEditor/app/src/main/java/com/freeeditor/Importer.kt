package com.freeeditor

import android.content.Context
import android.content.Intent
import android.media.MediaMetadataRetriever
import android.net.Uri
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.effect.Presentation
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Composition
import androidx.media3.transformer.Transformer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID
import kotlin.coroutines.resume

object Importer {
    class Probe(val durationMs: Long, val width: Int, val height: Int)

    fun probe(ctx: Context, uri: Uri): Probe? = runCatching {
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(ctx, uri)
            val d = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLong() ?: 0L
            var w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toInt() ?: 0
            var h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toInt() ?: 0
            val rot = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toInt() ?: 0
            if (rot == 90 || rot == 270) { val x = w; w = h; h = x }
            Probe(d, w, h)
        } finally { r.release() }
    }.getOrNull()

    fun hasAudio(ctx: Context, uri: Uri): Boolean = runCatching {
        val r = MediaMetadataRetriever()
        try { r.setDataSource(ctx, uri); r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_HAS_AUDIO) == "yes" }
        finally { r.release() }
    }.getOrDefault(false)

    private fun displayName(ctx: Context, uri: Uri): String = runCatching {
        ctx.contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) it.getString(0) else null
        }
    }.getOrNull() ?: "Audio"

    /** Copies a picked image into the app (gallery access is temporary) and returns its local uri. */
    suspend fun importImage(ctx: Context, uri: Uri): Pair<String, String>? = withContext(Dispatchers.IO) {
        runCatching {
            val dir = File(ctx.filesDir, "media").apply { mkdirs() }
            val ext = (ctx.contentResolver.getType(uri) ?: "image/png").substringAfter('/').let { if (it == "jpeg") "jpg" else it }
            val f = File(dir, "${UUID.randomUUID()}.$ext")
            ctx.contentResolver.openInputStream(uri)?.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
            Uri.fromFile(f).toString() to displayName(ctx, uri)
        }.getOrNull()
    }

    /** Imports an audio file (music, sound effect). Keeps a private copy when no permanent access is granted. */
    suspend fun importAudio(ctx: Context, uri: Uri, startMs: Long): AudioClip? {
        val dir = File(ctx.filesDir, "media").apply { mkdirs() }
        val name = displayName(ctx, uri)
        val persisted = runCatching {
            ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION); true
        }.getOrDefault(false)
        val finalUri = if (persisted) uri else withContext(Dispatchers.IO) {
            val f = File(dir, "${UUID.randomUUID()}.${name.substringAfterLast('.', "m4a")}")
            ctx.contentResolver.openInputStream(uri)?.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
            Uri.fromFile(f)
        }
        val p = probe(ctx, finalUri) ?: return null
        if (p.durationMs <= 0) return null
        return AudioClip(uri = finalUri.toString(), name = name, startMs = startMs, inMs = 0, outMs = p.durationMs, sourceMs = p.durationMs)
    }

    /** Imports a photo or video picked from the gallery. Photos become a 3-second video clip. Call on the main thread. */
    suspend fun import(ctx: Context, uri: Uri): Clip? {
        val mime = ctx.contentResolver.getType(uri) ?: ""
        val dir = File(ctx.filesDir, "media").apply { mkdirs() }
        val finalUri: Uri = if (mime.startsWith("image/")) {
            val out = File(dir, "${UUID.randomUUID()}.mp4")
            if (!imageToVideo(ctx, uri, mime, out)) return null
            Uri.fromFile(out)
        } else {
            val persisted = runCatching {
                ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION); true
            }.getOrDefault(false)
            if (persisted) uri else withContext(Dispatchers.IO) {
                // Gallery (photo picker) grants are temporary, so keep a private copy for the project.
                val f = File(dir, "${UUID.randomUUID()}.mp4")
                ctx.contentResolver.openInputStream(uri)?.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
                Uri.fromFile(f)
            }
        }
        val p = probe(ctx, finalUri) ?: return null
        if (p.durationMs <= 0) return null
        return Clip(uri = finalUri.toString(), inMs = 0, outMs = p.durationMs, sourceMs = p.durationMs,
            width = p.width, height = p.height)
    }

    private suspend fun imageToVideo(ctx: Context, uri: Uri, mime: String, out: File, durationMs: Long = 3000): Boolean =
        suspendCancellableCoroutine { cont ->
            val mi = MediaItem.Builder().setUri(uri).setMimeType(mime).build()
            val edited = EditedMediaItem.Builder(mi)
                .setDurationUs(durationMs * 1000).setFrameRate(30)
                .setEffects(Effects(emptyList(), listOf<Effect>(Presentation.createForHeight(1080))))
                .build()
            val t = Transformer.Builder(ctx)
                .setVideoMimeType(MimeTypes.VIDEO_H264)
                .addListener(object : Transformer.Listener {
                    override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                        if (cont.isActive) cont.resume(true)
                    }
                    override fun onError(composition: Composition, exportResult: ExportResult, exportException: ExportException) {
                        out.delete(); if (cont.isActive) cont.resume(false)
                    }
                }).build()
            cont.invokeOnCancellation { t.cancel() }
            t.start(edited, out.absolutePath)
        }
}
