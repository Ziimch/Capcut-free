package com.freeeditor

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.roundToInt

/** A keyframe on one property. [c] is a cubic-bezier easing (x1,y1,x2,y2) used from this keyframe to the next. */
data class Keyframe(val prop: String, val tMs: Long, val value: Float, val c: List<Float> = EASE_PRESETS.getValue("Ease in-out"))

val EASE_PRESETS: Map<String, List<Float>> = linkedMapOf(
    "Linear" to listOf(0f, 0f, 1f, 1f),
    "Ease in" to listOf(0.42f, 0f, 1f, 1f),
    "Ease out" to listOf(0f, 0f, 0.58f, 1f),
    "Ease in-out" to listOf(0.42f, 0f, 0.58f, 1f),
    "Overshoot" to listOf(0.34f, 1.56f, 0.64f, 1f),
)

private const val TOL = 40L

fun localTime(start: Long, dur: Long, playhead: Long): Long = (playhead - start).coerceIn(0L, dur)

private fun bx(c: List<Float>, t: Float): Float { val m = 1 - t; return 3 * m * m * t * c[0] + 3 * m * t * t * c[2] + t * t * t }
private fun by(c: List<Float>, t: Float): Float { val m = 1 - t; return 3 * m * m * t * c[1] + 3 * m * t * t * c[3] + t * t * t }

/** Eased progress for linear progress u in 0..1. */
fun bezier(c: List<Float>, u: Float): Float {
    var lo = 0f; var hi = 1f
    repeat(18) { val mid = (lo + hi) / 2; if (bx(c, mid) < u) lo = mid else hi = mid }
    return by(c, (lo + hi) / 2)
}

fun evalProp(kfs: List<Keyframe>, prop: String, localMs: Long, base: Float): Float {
    if (kfs.isEmpty()) return base
    val list = kfs.filter { it.prop == prop }.sortedBy { it.tMs }
    if (list.isEmpty()) return base
    if (localMs <= list.first().tMs) return list.first().value
    if (localMs >= list.last().tMs) return list.last().value
    val i = list.indexOfLast { it.tMs <= localMs }
    val a = list[i]; val b = list[i + 1]
    val u = (localMs - a.tMs).toFloat() / (b.tMs - a.tMs)
    return a.value + (b.value - a.value) * bezier(a.c, u)
}

class Xform(val x: Float, val y: Float, val scale: Float, val rot: Float, val op: Float)

fun xformOf(kfs: List<Keyframe>, local: Long, x: Float, y: Float, scale: Float, rot: Float, op: Float) = Xform(
    evalProp(kfs, "x", local, x), evalProp(kfs, "y", local, y), evalProp(kfs, "scale", local, scale),
    evalProp(kfs, "rot", local, rot), evalProp(kfs, "op", local, op))

fun upsertKf(kfs: List<Keyframe>, prop: String, t: Long, v: Float): List<Keyframe> {
    val ex = kfs.find { it.prop == prop && abs(it.tMs - t) <= TOL }
    return if (ex != null) kfs.map { if (it === ex) it.copy(value = v) else it } else kfs + Keyframe(prop, t, v)
}
fun removeKfAt(kfs: List<Keyframe>, props: List<String>, t: Long) = kfs.filterNot { it.prop in props && abs(it.tMs - t) <= TOL }
fun hasKfAt(kfs: List<Keyframe>, props: List<String>, t: Long) = kfs.any { it.prop in props && abs(it.tMs - t) <= TOL }

/** Writes values as keyframes for animated properties, or into the base value otherwise (auto-keyframe). */
fun TextItem.withProps(local: Long, v: Map<String, Float>): TextItem {
    var k = kfs; var t = this
    for ((p, value) in v) {
        if (k.any { it.prop == p }) k = upsertKf(k, p, local, value)
        else t = when (p) {
            "x" -> t.copy(x = value); "y" -> t.copy(y = value); "scale" -> t.copy(scale = value)
            "rot" -> t.copy(rotation = value); "op" -> t.copy(opacity = value); else -> t
        }
    }
    return t.copy(kfs = k)
}

fun ImageLayer.withProps(local: Long, v: Map<String, Float>): ImageLayer {
    var k = kfs; var t = this
    for ((p, value) in v) {
        if (k.any { it.prop == p }) k = upsertKf(k, p, local, value)
        else t = when (p) {
            "x" -> t.copy(x = value); "y" -> t.copy(y = value); "scale" -> t.copy(scale = value)
            "rot" -> t.copy(rotation = value); "op" -> t.copy(opacity = value); else -> t
        }
    }
    return t.copy(kfs = k)
}

/** Dotted motion path + keyframe dots on the preview for the selected layer. */
fun DrawScope.drawMotionPath(kfs: List<Keyframe>, dur: Long, baseX: Float, baseY: Float) {
    if (kfs.none { it.prop == "x" || it.prop == "y" }) return
    var prev: Offset? = null
    val steps = 40
    for (i in 0..steps) {
        val t = dur * i / steps
        val p = Offset(evalProp(kfs, "x", t, baseX) * size.width, evalProp(kfs, "y", t, baseY) * size.height)
        prev?.let { drawLine(Color(0xAAFFFFFF), it, p, 3f) }
        prev = p
    }
    kfs.filter { it.prop == "x" || it.prop == "y" }.map { it.tMs }.distinct().forEach { t ->
        drawCircle(Color(0xFFFFD600), 9f, Offset(evalProp(kfs, "x", t, baseX) * size.width, evalProp(kfs, "y", t, baseY) * size.height))
    }
}

class KfHandlers(
    val playhead: () -> Long,
    val onProps: (Map<String, Float>, Boolean) -> Unit,
    val onKfs: (List<Keyframe>, Boolean) -> Unit,
    val onSeek: (Long) -> Unit,
)

private val GROUPS = listOf("Position" to listOf("x", "y"), "Scale" to listOf("scale"), "Rotation" to listOf("rot"), "Opacity" to listOf("op"))

@Composable
fun KeyframeControls(
    startMs: Long, durMs: Long, kfs: List<Keyframe>,
    x: Float, y: Float, scale: Float, rot: Float, op: Float,
    scaleRange: ClosedFloatingPointRange<Float>, h: KfHandlers,
) {
    val local = localTime(startMs, durMs, h.playhead())   // only this composable follows the playhead
    val cx = evalProp(kfs, "x", local, x); val cy = evalProp(kfs, "y", local, y)
    val cs = evalProp(kfs, "scale", local, scale); val cr = evalProp(kfs, "rot", local, rot)
    val co = evalProp(kfs, "op", local, op)
    var curveOpen by remember { mutableStateOf(false) }
    val times = kfs.map { it.tMs }.distinct().sorted()
    val atNow = kfs.filter { abs(it.tMs - local) <= TOL }

    Text("Keyframes at ${"%.1f".format(local / 1000f)}s  (tap a diamond to add or remove)", style = MaterialTheme.typography.labelSmall)
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
        IconButton(enabled = times.any { it < local - TOL }, onClick = { times.lastOrNull { it < local - TOL }?.let { h.onSeek(startMs + it) } }) {
            Icon(Icons.Default.ChevronLeft, "Previous keyframe")
        }
        GROUPS.forEach { (label, props) ->
            val active = hasKfAt(kfs, props, local)
            FilterChip(selected = active, label = { Text((if (active) "◆ " else "◇ ") + label) }, onClick = {
                if (active) h.onKfs(removeKfAt(kfs, props, local), true)
                else {
                    var k = kfs
                    props.forEach { p -> k = upsertKf(k, p, local, when (p) { "x" -> cx; "y" -> cy; "scale" -> cs; "rot" -> cr; else -> co }) }
                    h.onKfs(k, true)
                }
            })
        }
        IconButton(enabled = times.any { it > local + TOL }, onClick = { times.firstOrNull { it > local + TOL }?.let { h.onSeek(startMs + it) } }) {
            Icon(Icons.Default.ChevronRight, "Next keyframe")
        }
    }

    Text("Position X ${(cx * 100).roundToInt()}%", style = MaterialTheme.typography.labelSmall)
    Slider(value = cx.coerceIn(0f, 1f), onValueChange = { h.onProps(mapOf("x" to it), false) }, valueRange = 0f..1f)
    Text("Position Y ${(cy * 100).roundToInt()}%", style = MaterialTheme.typography.labelSmall)
    Slider(value = cy.coerceIn(0f, 1f), onValueChange = { h.onProps(mapOf("y" to it), false) }, valueRange = 0f..1f)
    Text("Opacity ${(co * 100).roundToInt()}%", style = MaterialTheme.typography.labelSmall)
    Slider(value = co.coerceIn(0f, 1f), onValueChange = { h.onProps(mapOf("op" to it), false) }, valueRange = 0f..1f)
    Text("Rotation ${cr.roundToInt()} deg", style = MaterialTheme.typography.labelSmall)
    Slider(value = cr.coerceIn(-360f, 360f), onValueChange = { h.onProps(mapOf("rot" to it), false) }, valueRange = -360f..360f)
    Text("Scale ${"%.2f".format(cs)}", style = MaterialTheme.typography.labelSmall)
    Slider(value = cs.coerceIn(scaleRange), onValueChange = { h.onProps(mapOf("scale" to it), false) }, valueRange = scaleRange)

    Text(if (atNow.isEmpty()) "Easing (move the playhead onto a keyframe)" else "Easing of this keyframe", style = MaterialTheme.typography.labelSmall)
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
        EASE_PRESETS.forEach { (name, c) ->
            FilterChip(selected = atNow.isNotEmpty() && atNow.all { it.c == c }, enabled = atNow.isNotEmpty(),
                label = { Text(name) },
                onClick = { h.onKfs(kfs.map { if (abs(it.tMs - local) <= TOL) it.copy(c = c) else it }, true) })
        }
        TextButton(enabled = atNow.isNotEmpty(), onClick = { curveOpen = true }) { Text("Curve") }
    }
    if (curveOpen && atNow.isNotEmpty()) {
        AlertDialog(
            onDismissRequest = { curveOpen = false },
            confirmButton = { TextButton(onClick = { curveOpen = false }) { Text("Done") } },
            title = { Text("Easing curve") },
            text = {
                CurveEditor(atNow.first().c) { c -> h.onKfs(kfs.map { if (abs(it.tMs - local) <= TOL) it.copy(c = c) else it }, false) }
            },
        )
    }
}

/** Drag the two handles to shape the cubic-bezier easing. Vertical range allows overshoot. */
@Composable
fun CurveEditor(ease: List<Float>, onChange: (List<Float>) -> Unit) {
    val e by rememberUpdatedState(ease)
    val cb by rememberUpdatedState(onChange)
    Canvas(
        Modifier.size(220.dp).background(Color(0xFF1A1A1E)).pointerInput(Unit) {
            var active = 0
            detectDragGestures(
                onDragStart = { o ->
                    val w = size.width.toFloat(); val hh = size.height.toFloat()
                    val d1 = hypot(o.x - e[0] * w, o.y - (1.5f - e[1]) / 2f * hh)
                    val d2 = hypot(o.x - e[2] * w, o.y - (1.5f - e[3]) / 2f * hh)
                    active = if (d1 <= d2) 0 else 1
                },
                onDrag = { change, _ ->
                    change.consume()
                    val w = size.width.toFloat(); val hh = size.height.toFloat()
                    val nx = (change.position.x / w).coerceIn(0f, 1f)
                    val ny = (1.5f - change.position.y / hh * 2f).coerceIn(-0.5f, 1.5f)
                    val c = e.toMutableList()
                    if (active == 0) { c[0] = nx; c[1] = ny } else { c[2] = nx; c[3] = ny }
                    cb(c)
                })
        }
    ) {
        val w = size.width; val hh = size.height
        fun px(x: Float) = x * w
        fun py(y: Float) = (1.5f - y) / 2f * hh
        drawLine(Color(0x55FFFFFF), Offset(0f, py(0f)), Offset(w, py(0f)), 2f)
        drawLine(Color(0x55FFFFFF), Offset(0f, py(1f)), Offset(w, py(1f)), 2f)
        var prev = Offset(px(0f), py(0f))
        for (i in 1..40) {
            val t = i / 40f
            val p = Offset(px(bx(e, t)), py(by(e, t)))
            drawLine(Color(0xFF4DD0E1), prev, p, 5f); prev = p
        }
        drawLine(Color(0x88FFFFFF), Offset(px(0f), py(0f)), Offset(px(e[0]), py(e[1])), 2f)
        drawLine(Color(0x88FFFFFF), Offset(px(1f), py(1f)), Offset(px(e[2]), py(e[3])), 2f)
        drawCircle(Color(0xFFFFD600), 14f, Offset(px(e[0]), py(e[1])))
        drawCircle(Color(0xFFFFD600), 14f, Offset(px(e[2]), py(e[3])))
    }
}
