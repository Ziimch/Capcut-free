package com.freeeditor

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint

val PRESETS = listOf("Title", "Caption", "Social", "Minimal", "Bold", "Cinematic")
val FONTS = listOf("SANS", "SERIF", "MONO", "CURSIVE", "CONDENSED")
val ANIMS = listOf("NONE", "FADE", "SLIDE", "POP")
val PALETTE = listOf(0xFFFFFFFF, 0xFF000000, 0xFFFFD600, 0xFFFF3B30, 0xFF4DD0E1, 0xFF34C759, 0xFFFF2D95, 0xFFFF9500)
    .map { it.toInt() }

fun applyPreset(t: TextItem, p: String): TextItem = when (p) {
    "Title" -> t.copy(size = 0.09f, bold = true, italic = false, font = "SANS", color = PALETTE[0],
        outline = false, shadow = true, y = 0.5f, animIn = "FADE", animOut = "FADE", animMs = 500)
    "Caption" -> t.copy(size = 0.045f, bold = false, italic = false, font = "SANS", color = PALETTE[0],
        outline = false, shadow = true, y = 0.88f, animIn = "NONE", animOut = "NONE")
    "Social" -> t.copy(size = 0.055f, bold = true, italic = false, font = "SANS", color = PALETTE[0],
        outline = true, shadow = false, y = 0.75f, animIn = "POP", animOut = "FADE", animMs = 300)
    "Minimal" -> t.copy(size = 0.04f, bold = false, italic = false, font = "SANS", color = PALETTE[0],
        outline = false, shadow = false, y = 0.5f, animIn = "FADE", animOut = "FADE", animMs = 600)
    "Bold" -> t.copy(size = 0.11f, bold = true, italic = false, font = "CONDENSED", color = PALETTE[2],
        outline = true, shadow = false, y = 0.35f, animIn = "POP", animOut = "POP", animMs = 300)
    "Cinematic" -> t.copy(size = 0.06f, bold = false, italic = false, font = "SERIF", color = PALETTE[0],
        outline = false, shadow = true, y = 0.5f, animIn = "FADE", animOut = "FADE", animMs = 900)
    else -> t
}

/** Draws one text layer. Shared by the live preview and the exporter. */
object TextRender {
    fun typeface(font: String, bold: Boolean, italic: Boolean): Typeface {
        val style = when {
            bold && italic -> Typeface.BOLD_ITALIC
            bold -> Typeface.BOLD
            italic -> Typeface.ITALIC
            else -> Typeface.NORMAL
        }
        val family = when (font) {
            "SERIF" -> "serif"; "MONO" -> "monospace"; "CURSIVE" -> "cursive"
            "CONDENSED" -> "sans-serif-condensed"; else -> "sans-serif"
        }
        return Typeface.create(family, style)
    }

    fun drawText(canvas: Canvas, w: Int, h: Int, t: TextItem, ms: Long) {
        if (t.text.isBlank()) return
        val st = animState(t.animIn, t.animOut, t.animMs, t.startMs, t.durationMs, ms, h)
        val xf = xformOf(t.kfs, (ms - t.startMs).coerceAtLeast(0), t.x, t.y, t.scale, t.rotation, t.opacity)
        val alpha = st.alpha * xf.op
        if (alpha <= 0.01f) return

        val paint = TextPaint(Paint.ANTI_ALIAS_FLAG)
        paint.textSize = (t.size * h).coerceAtLeast(4f)
        paint.typeface = typeface(t.font, t.bold, t.italic)
        val width = (0.9f * w).toInt().coerceAtLeast(10)
        val layout = StaticLayout.Builder.obtain(t.text, 0, t.text.length, paint, width)
            .setAlignment(Layout.Alignment.ALIGN_CENTER).build()

        canvas.save()
        canvas.translate(xf.x * w, xf.y * h + st.dy)
        canvas.rotate(xf.rot)
        val sc = st.scale * xf.scale
        canvas.scale(sc, sc)
        canvas.translate(-width / 2f, -layout.height / 2f)
        if (t.outline) {
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = paint.textSize * 0.14f
            paint.strokeJoin = Paint.Join.ROUND
            paint.color = Color.argb((255 * alpha).toInt(), 0, 0, 0)
            layout.draw(canvas)
        }
        paint.style = Paint.Style.FILL
        paint.color = Color.argb((Color.alpha(t.color) * alpha).toInt(), Color.red(t.color), Color.green(t.color), Color.blue(t.color))
        if (t.shadow) paint.setShadowLayer(paint.textSize * 0.08f, paint.textSize * 0.04f, paint.textSize * 0.04f,
            Color.argb((160 * alpha).toInt(), 0, 0, 0))
        layout.draw(canvas)
        canvas.restore()
    }
}
