package com.freeeditor

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import androidx.media3.effect.BitmapOverlay

val PRESETS = listOf("Title", "Caption", "Social", "Minimal", "Bold", "Cinematic")
val FONTS = listOf("SANS", "SERIF", "MONO", "CURSIVE", "CONDENSED")
val ANIMS = listOf("NONE", "FADE", "SLIDE", "POP")
val PALETTE = listOf(0xFFFFFFFF, 0xFF000000, 0xFFFFD600, 0xFFFF3B30, 0xFF4DD0E1, 0xFF34C759, 0xFFFF2D95, 0xFFFF9500)
    .map { it.toInt() }

fun applyPreset(t: TextItem, p: String): TextItem = when (p) {
    "Title" -> t.copy(size = 0.09f, bold = true, italic = false, font = "SANS", color = PALETTE[0],
        outline = false, shadow = true, y = 0.5f, animIn = "FADE", animOut = "FADE", animMs = 500)
    "Caption" -> t.copy(size = 0.045f, bold = false, italic = false, font = "SANS", color = PALETTE[0],
        outline = false, shadow = true, y = 0.88f, animIn = "NONE", animOut = "NONE")
    "Social" -> t.copy(size = 0.055f, bold = true, italic = false, font = "SANS", color = PALETTE[0],
        outline = true, shadow = false, y = 0.75f, animIn = "POP", animOut = "FADE", animMs = 300)
    "Minimal" -> t.copy(size = 0.04f, bold = false, italic = false, font = "SANS", color = PALETTE[0],
        outline = false, shadow = false, y = 0.5f, animIn = "FADE", animOut = "FADE", animMs = 600)
    "Bold" -> t.copy(size = 0.11f, bold = true, italic = false, font = "CONDENSED", color = PALETTE[2],
        outline = true, shadow = false, y = 0.35f, animIn = "POP", animOut = "POP", animMs = 300)
    "Cinematic" -> t.copy(size = 0.06f, bold = false, italic = false, font = "SERIF", color = PALETTE[0],
        outline = false, shadow = true, y = 0.5f, animIn = "FADE", animOut = "FADE", animMs = 900)
    else -> t
}

/** One renderer used by BOTH the live preview and the exporter, so they always match. */
object TextRender {
    fun typeface(font: String, bold: Boolean, italic: Boolean): Typeface {
        val style = when {
            bold && italic -> Typeface.BOLD_ITALIC
            bold -> Typeface.BOLD
            italic -> Typeface.ITALIC
            else -> Typeface.NORMAL
        }
        val family = when (font) {
            "SERIF" -> "serif"; "MONO" -> "monospace"; "CURSIVE" -> "cursive"
            "CONDENSED" -> "sans-serif-condensed"; else -> "sans-serif"
        }
        return Typeface.create(family, style)
    }

    fun isActive(t: TextItem, ms: Long) = ms >= t.startMs && ms < t.startMs + t.durationMs

    private fun am(t: TextItem) = minOf(t.animMs, t.durationMs / 2).coerceAtLeast(1)

    fun isAnimating(t: TextItem, ms: Long): Boolean =
        (t.animIn != "NONE" && ms - t.startMs < am(t)) ||
            (t.animOut != "NONE" && t.startMs + t.durationMs - ms < am(t))

    fun draw(canvas: Canvas, w: Int, h: Int, items: List<TextItem>, ms: Long) {
        for (t in items) if (isActive(t, ms) && t.text.isNotBlank()) drawOne(canvas, w, h, t, ms)
    }

    private fun drawOne(canvas: Canvas, w: Int, h: Int, t: TextItem, ms: Long) {
        val a = am(t).toFloat()
        val tin = if (t.animIn == "NONE") 1f else ((ms - t.startMs) / a).coerceIn(0f, 1f)
        val tout = if (t.animOut == "NONE") 1f else ((t.startMs + t.durationMs - ms) / a).coerceIn(0f, 1f)
        var alpha = 1f; var dy = 0f; var scale = 1f
        when (t.animIn) {
            "FADE" -> alpha *= tin
            "SLIDE" -> { alpha *= tin; dy += (1f - tin) * 0.06f * h }
            "POP" -> { alpha *= tin; scale *= 0.5f + 0.5f * tin }
        }
        when (t.animOut) {
            "FADE" -> alpha *= tout
            "SLIDE" -> { alpha *= tout; dy -= (1f - tout) * 0.06f * h }
            "POP" -> { alpha *= tout; scale *= 0.5f + 0.5f * tout }
        }
        if (alpha <= 0.01f) return

        val paint = TextPaint(Paint.ANTI_ALIAS_FLAG)
        paint.textSize = (t.size * h).coerceAtLeast(4f)
        paint.typeface = typeface(t.font, t.bold, t.italic)
        val width = (0.9f * w).toInt().coerceAtLeast(10)
        val layout = StaticLayout.Builder.obtain(t.text, 0, t.text.length, paint, width)
            .setAlignment(Layout.Alignment.ALIGN_CENTER).build()

        canvas.save()
        canvas.translate(t.x * w, t.y * h + dy)
        canvas.scale(scale, scale)
        canvas.translate(-width / 2f, -layout.height / 2f)
        if (t.outline) {
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = paint.textSize * 0.14f
            paint.strokeJoin = Paint.Join.ROUND
            paint.color = Color.argb((255 * alpha).toInt(), 0, 0, 0)
            layout.draw(canvas)
        }
        paint.style = Paint.Style.FILL
        paint.color = Color.argb((Color.alpha(t.color) * alpha).toInt(), Color.red(t.color), Color.green(t.color), Color.blue(t.color))
        if (t.shadow) paint.setShadowLayer(paint.textSize * 0.08f, paint.textSize * 0.04f, paint.textSize * 0.04f,
            Color.argb((160 * alpha).toInt(), 0, 0, 0))
        layout.draw(canvas)
        canvas.restore()
    }
}

/** Full-frame transparent bitmap overlay for the Media3 exporter (text drawn at export resolution). */
class TextBitmapOverlay(private val w: Int, private val h: Int, private val items: List<TextItem>) : BitmapOverlay() {
    private var lastKey: String? = null
    private var lastBmp: Bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)

    override fun getBitmap(presentationTimeUs: Long): Bitmap {
        val ms = presentationTimeUs / 1000
        val active = items.filter { TextRender.isActive(it, ms) }
        val key = if (active.isEmpty()) "empty" else active.joinToString("|") {
            if (TextRender.isAnimating(it, ms)) "${it.id}@${ms / 40}" else it.id
        }
        if (key != lastKey) {
            val b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            TextRender.draw(Canvas(b), w, h, active, ms)
            lastBmp = b; lastKey = key
        }
        return lastBmp
    }
}
