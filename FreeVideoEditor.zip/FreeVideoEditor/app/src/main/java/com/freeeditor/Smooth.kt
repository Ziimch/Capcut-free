package com.freeeditor

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp

/**
 * Same-package Slider: wins over the material3 star-import in every file, so all sliders become smooth.
 * Keeps its own value while dragging and forwards at most ~25 updates/s; the final value is always sent.
 */
@Composable
fun Slider(
    value: Float,
    onValueChange: (Float) -> Unit,
    modifier: Modifier = Modifier,
    valueRange: ClosedFloatingPointRange<Float> = 0f..1f,
    steps: Int = 0,
) {
    var local by remember { mutableStateOf(value) }
    var dragging by remember { mutableStateOf(false) }
    var last by remember { mutableStateOf(0L) }
    val cb by rememberUpdatedState(onValueChange)
    val shown = if (dragging) local else value
    androidx.compose.material3.Slider(
        value = shown.coerceIn(valueRange.start, valueRange.endInclusive),
        onValueChange = {
            dragging = true; local = it
            val now = System.nanoTime() / 1_000_000L
            if (now - last >= 40L) { last = now; cb(it) }
        },
        onValueChangeFinished = { cb(local); dragging = false },
        modifier = modifier, valueRange = valueRange, steps = steps,
    )
}

/** Timeline bar for a layer: tap = select, long-press + drag = move, edge handles (when selected) = trim. */
@Composable
fun LayerBar(
    startMs: Long, durMs: Long, zoom: Float, sel: Boolean, color: Color, label: String, dim: Boolean,
    kfTimes: List<Long>, modifier: Modifier,
    onClick: () -> Unit, onDragStart: () -> Unit, onMove: (Long) -> Unit, onTrim: (Long, Long) -> Unit,
    selColor: Color? = null,
    inner: @Composable BoxScope.() -> Unit = {},
) {
    val curStart by rememberUpdatedState(startMs)
    val curDur by rememberUpdatedState(durMs)
    val curZoom by rememberUpdatedState(zoom)
    val moveCb by rememberUpdatedState(onMove)
    val trimCb by rememberUpdatedState(onTrim)
    val startCb by rememberUpdatedState(onDragStart)
    Box(
        modifier.width((durMs / 1000f * zoom).dp).height(30.dp).padding(horizontal = 1.dp)
            .alpha(if (dim) 0.4f else 1f).clip(RoundedCornerShape(5.dp))
            .background(if (sel) (selColor ?: MaterialTheme.colorScheme.primary) else color)
            .pointerInput(Unit) {
                var acc = 0f; var base = 0L
                detectDragGesturesAfterLongPress(
                    onDragStart = { acc = 0f; base = curStart; startCb() },
                    onDrag = { c, d ->
                        c.consume(); acc += d.x
                        moveCb((base + (acc / (curZoom * density / 1000f)).toLong()).coerceAtLeast(0L))
                    })
            }
            .clickable(onClick = onClick)
    ) {
        inner()
        if (kfTimes.isNotEmpty()) androidx.compose.foundation.Canvas(Modifier.fillMaxSize()) {
            kfTimes.forEach { t -> drawCircle(Color(0xFFFFD600), 5f, Offset(t / 1000f * zoom * density, size.height - 8f)) }
        }
        Text(label, Modifier.padding(horizontal = 18.dp).align(Alignment.CenterStart), maxLines = 1, softWrap = false,
            style = MaterialTheme.typography.labelSmall, color = if (sel) Color.Black else Color.White)
        if (sel) {
            Box(Modifier.align(Alignment.CenterStart).width(16.dp).fillMaxHeight().background(Color(0x66000000))
                .pointerInput(Unit) {
                    var acc = 0f; var s0 = 0L; var d0 = 0L
                    detectHorizontalDragGestures(onDragStart = { acc = 0f; s0 = curStart; d0 = curDur; startCb() }) { c, dx ->
                        c.consume(); acc += dx
                        val ns = (s0 + (acc / (curZoom * density / 1000f)).toLong()).coerceAtLeast(0L)
                        val nd = d0 - (ns - s0)
                        if (nd >= 300L) trimCb(ns, nd)
                    }
                })
            Box(Modifier.align(Alignment.CenterEnd).width(16.dp).fillMaxHeight().background(Color(0x66000000))
                .pointerInput(Unit) {
                    var acc = 0f; var s0 = 0L; var d0 = 0L
                    detectHorizontalDragGestures(onDragStart = { acc = 0f; s0 = curStart; d0 = curDur; startCb() }) { c, dx ->
                        c.consume(); acc += dx
                        val nd = d0 + (acc / (curZoom * density / 1000f)).toLong()
                        if (nd >= 300L) trimCb(s0, nd)
                    }
                })
        }
    }
}
