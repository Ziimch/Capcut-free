package com.freeeditor

import android.content.Context
import android.net.Uri
import android.os.Handler
import android.os.Looper
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.effect.OverlayEffect
import androidx.media3.effect.Presentation
import androidx.media3.effect.TextureOverlay
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import com.google.common.collect.ImmutableList
import java.io.File

fun outputSize(clips: List<Clip>): Pair<Int, Int> {
    val c = clips.firstOrNull()
    var w = c?.width ?: 0; var h = c?.height ?: 0
    if (w <= 0 || h <= 0) { w = 1280; h = 720 }
    val s = minOf(1f, 1920f / maxOf(w, h))
    return ((w * s).toInt() / 2 * 2).coerceAtLeast(2) to ((h * s).toInt() / 2 * 2).coerceAtLeast(2)
}

/** Real export using Media3 Transformer (MediaCodec). Call on the main thread. */
class Exporter(private val context: Context) {
    private val handler = Handler(Looper.getMainLooper())
    private var transformer: Transformer? = null
    private var polling = false
    private val temp = mutableListOf<File>()

    fun start(project: Project, out: File, onProgress: (Int) -> Unit, onDone: (Result<File>) -> Unit) {
        val clips = project.clips; val texts = project.texts
        val (w, h) = outputSize(clips)
        val totalMs = clips.sumOf { it.durationMs }

        val items = clips.map {
            val mi = MediaItem.Builder().setUri(Uri.parse(it.uri))
                .setClippingConfiguration(
                    MediaItem.ClippingConfiguration.Builder()
                        .setStartPositionMs(it.inMs).setEndPositionMs(it.outMs).build())
                .build()
            val b = EditedMediaItem.Builder(mi)
            if (it.volume != 1f) b.setEffects(Effects(
                listOf<AudioProcessor>(GainFadeProcessor(it.volume, 0, 0, it.durationMs)), emptyList<Effect>()))
            b.build()
        }
        val sequences = mutableListOf(EditedMediaItemSequence(items))

        // Each audio clip is its own sequence: [silence up to its start] + [the clip with volume/fades].
        for (a in project.audios) {
            val dur = minOf(a.endMs, totalMs) - a.startMs
            if (dur < 200) continue
            val list = mutableListOf<EditedMediaItem>()
            if (a.startMs > 0) {
                val wav = Silence.create(context, a.startMs); temp.add(wav)
                list.add(EditedMediaItem.Builder(MediaItem.fromUri(Uri.fromFile(wav))).build())
            }
            val mi = MediaItem.Builder().setUri(Uri.parse(a.uri)).setClippingConfiguration(
                MediaItem.ClippingConfiguration.Builder().setStartPositionMs(a.inMs).setEndPositionMs(a.inMs + dur).build()).build()
            list.add(EditedMediaItem.Builder(mi).setRemoveVideo(true).setEffects(Effects(
                listOf<AudioProcessor>(GainFadeProcessor(a.volume, a.fadeInMs, a.fadeOutMs, dur)), emptyList<Effect>())).build())
            sequences.add(EditedMediaItemSequence(list))
        }

        val videoEffects = mutableListOf<Effect>(Presentation.createForWidthAndHeight(w, h, Presentation.LAYOUT_SCALE_TO_FIT))
        if (texts.isNotEmpty() || project.images.isNotEmpty() || project.shapes.isNotEmpty()) {
            videoEffects.add(OverlayEffect(ImmutableList.of<TextureOverlay>(LayerBitmapOverlay(context, w, h, texts, project.images, project.shapes))))
        }
        val composition = Composition.Builder(sequences)
            .setEffects(Effects(emptyList<AudioProcessor>(), videoEffects))
            .build()
        val t = Transformer.Builder(context)
            .setVideoMimeType(MimeTypes.VIDEO_H264)
            .setAudioMimeType(MimeTypes.AUDIO_AAC)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    polling = false; cleanup(); onDone(Result.success(out))
                }
                override fun onError(composition: Composition, exportResult: ExportResult, exportException: ExportException) {
                    polling = false; cleanup(); out.delete(); onDone(Result.failure(exportException))
                }
            }).build()
        transformer = t
        out.parentFile?.mkdirs(); out.delete()
        t.start(composition, out.absolutePath)
        polling = true
        val holder = ProgressHolder()
        handler.post(object : Runnable {
            override fun run() {
                if (!polling) return
                if (t.getProgress(holder) != Transformer.PROGRESS_STATE_NOT_STARTED) onProgress(holder.progress)
                handler.postDelayed(this, 300)
            }
        })
    }

    private fun cleanup() { temp.forEach { it.delete() }; temp.clear() }
    fun cancel() { polling = false; transformer?.cancel(); cleanup() }
}
