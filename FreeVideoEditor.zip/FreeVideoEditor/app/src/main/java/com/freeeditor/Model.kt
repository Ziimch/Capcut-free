package com.freeeditor

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

data class Clip(
    val id: String = UUID.randomUUID().toString(),
    val uri: String,
    val inMs: Long,
    val outMs: Long,
    val sourceMs: Long,
    val width: Int = 0,
    val height: Int = 0,
    val volume: Float = 1f,
) { val durationMs: Long get() = outMs - inMs }

data class AudioClip(
    val id: String = UUID.randomUUID().toString(),
    val uri: String,
    val name: String = "Audio",
    val startMs: Long,            // position on the timeline
    val inMs: Long,               // trim inside the source file
    val outMs: Long,
    val sourceMs: Long,
    val volume: Float = 1f,
    val fadeInMs: Long = 0,
    val fadeOutMs: Long = 0,
) {
    val durationMs: Long get() = outMs - inMs
    val endMs: Long get() = startMs + durationMs
}

data class TextItem(
    val id: String = UUID.randomUUID().toString(),
    val text: String = "Your text",
    val startMs: Long,
    val durationMs: Long = 3000,
    val x: Float = 0.5f,          // center, fraction of frame width
    val y: Float = 0.5f,          // center, fraction of frame height
    val size: Float = 0.07f,      // font size as fraction of frame height
    val color: Int = 0xFFFFFFFF.toInt(),
    val font: String = "SANS",    // SANS, SERIF, MONO, CURSIVE, CONDENSED
    val bold: Boolean = true,
    val italic: Boolean = false,
    val outline: Boolean = false,
    val shadow: Boolean = true,
    val animIn: String = "FADE",  // NONE, FADE, SLIDE, POP
    val animOut: String = "FADE",
    val animMs: Long = 400,
    val rotation: Float = 0f,     // degrees
    val scale: Float = 1f,        // multiplier on top of font size
    val opacity: Float = 1f,
    val visible: Boolean = true,
    val locked: Boolean = false,
    val name: String = "",
    val z: Int = 0,               // stacking order, higher = on top
)

data class ImageLayer(
    val id: String = UUID.randomUUID().toString(),
    val uri: String,
    val name: String = "Image",
    val startMs: Long,
    val durationMs: Long = 3000,
    val x: Float = 0.5f,
    val y: Float = 0.5f,
    val scale: Float = 0.4f,      // width as fraction of the frame width
    val rotation: Float = 0f,
    val opacity: Float = 1f,
    val visible: Boolean = true,
    val locked: Boolean = false,
    val animIn: String = "FADE",
    val animOut: String = "FADE",
    val animMs: Long = 400,
    val z: Int = 0,
)

data class Project(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val clips: List<Clip> = emptyList(),
    val texts: List<TextItem> = emptyList(),
    val audios: List<AudioClip> = emptyList(),
    val images: List<ImageLayer> = emptyList(),
    val updatedAt: Long = System.currentTimeMillis(),
)

class ProjectStore(context: Context) {
    private val dir = File(context.filesDir, "projects").apply { mkdirs() }

    fun save(p: Project) {
        val clips = JSONArray()
        p.clips.forEach {
            clips.put(JSONObject().put("id", it.id).put("uri", it.uri)
                .put("in", it.inMs).put("out", it.outMs).put("src", it.sourceMs)
                .put("w", it.width).put("h", it.height).put("vol", it.volume.toDouble()))
        }
        val texts = JSONArray()
        p.texts.forEach {
            texts.put(JSONObject().put("id", it.id).put("text", it.text).put("start", it.startMs)
                .put("dur", it.durationMs).put("x", it.x.toDouble()).put("y", it.y.toDouble())
                .put("size", it.size.toDouble()).put("color", it.color).put("font", it.font)
                .put("bold", it.bold).put("italic", it.italic).put("outline", it.outline)
                .put("shadow", it.shadow).put("animIn", it.animIn).put("animOut", it.animOut)
                .put("animMs", it.animMs).put("rot", it.rotation.toDouble()).put("scale", it.scale.toDouble())
                .put("op", it.opacity.toDouble()).put("vis", it.visible).put("lock", it.locked)
                .put("tname", it.name).put("z", it.z))
        }
        val images = JSONArray()
        p.images.forEach {
            images.put(JSONObject().put("id", it.id).put("uri", it.uri).put("name", it.name)
                .put("start", it.startMs).put("dur", it.durationMs).put("x", it.x.toDouble()).put("y", it.y.toDouble())
                .put("scale", it.scale.toDouble()).put("rot", it.rotation.toDouble()).put("op", it.opacity.toDouble())
                .put("vis", it.visible).put("lock", it.locked).put("animIn", it.animIn).put("animOut", it.animOut)
                .put("animMs", it.animMs).put("z", it.z))
        }
        val audios = JSONArray()
        p.audios.forEach {
            audios.put(JSONObject().put("id", it.id).put("uri", it.uri).put("name", it.name)
                .put("start", it.startMs).put("in", it.inMs).put("out", it.outMs).put("src", it.sourceMs)
                .put("vol", it.volume.toDouble()).put("fi", it.fadeInMs).put("fo", it.fadeOutMs))
        }
        val o = JSONObject().put("id", p.id).put("name", p.name)
            .put("updated", System.currentTimeMillis()).put("clips", clips).put("texts", texts).put("audios", audios).put("images", images)
        val tmp = File(dir, "${p.id}.tmp")
        tmp.writeText(o.toString())
        tmp.renameTo(File(dir, "${p.id}.json"))
    }

    fun loadAll(): List<Project> = (dir.listFiles { f -> f.extension == "json" } ?: emptyArray())
        .mapNotNull { runCatching { parse(it.readText()) }.getOrNull() }
        .sortedByDescending { it.updatedAt }

    fun delete(id: String) { File(dir, "$id.json").delete() }

    private fun parse(s: String): Project {
        val o = JSONObject(s)
        val a = o.getJSONArray("clips")
        val clips = (0 until a.length()).map {
            val c = a.getJSONObject(it)
            Clip(c.getString("id"), c.getString("uri"), c.getLong("in"), c.getLong("out"), c.getLong("src"),
                c.optInt("w", 0), c.optInt("h", 0), c.optDouble("vol", 1.0).toFloat())
        }
        val ta = o.optJSONArray("texts") ?: JSONArray()
        val texts = (0 until ta.length()).map {
            val t = ta.getJSONObject(it)
            TextItem(
                id = t.getString("id"), text = t.getString("text"), startMs = t.getLong("start"),
                durationMs = t.getLong("dur"), x = t.getDouble("x").toFloat(), y = t.getDouble("y").toFloat(),
                size = t.getDouble("size").toFloat(), color = t.getInt("color"), font = t.getString("font"),
                bold = t.getBoolean("bold"), italic = t.getBoolean("italic"), outline = t.getBoolean("outline"),
                shadow = t.getBoolean("shadow"), animIn = t.getString("animIn"), animOut = t.getString("animOut"),
                animMs = t.getLong("animMs"),
                rotation = t.optDouble("rot", 0.0).toFloat(), scale = t.optDouble("scale", 1.0).toFloat(),
                opacity = t.optDouble("op", 1.0).toFloat(), visible = t.optBoolean("vis", true),
                locked = t.optBoolean("lock", false), name = t.optString("tname", ""), z = t.optInt("z", 0),
            )
        }
        val aa = o.optJSONArray("audios") ?: JSONArray()
        val audios = (0 until aa.length()).map {
            val a = aa.getJSONObject(it)
            AudioClip(a.getString("id"), a.getString("uri"), a.optString("name", "Audio"), a.getLong("start"),
                a.getLong("in"), a.getLong("out"), a.getLong("src"), a.optDouble("vol", 1.0).toFloat(),
                a.optLong("fi", 0), a.optLong("fo", 0))
        }
        val ia = o.optJSONArray("images") ?: JSONArray()
        val images = (0 until ia.length()).map {
            val m = ia.getJSONObject(it)
            ImageLayer(
                id = m.getString("id"), uri = m.getString("uri"), name = m.optString("name", "Image"),
                startMs = m.getLong("start"), durationMs = m.getLong("dur"),
                x = m.getDouble("x").toFloat(), y = m.getDouble("y").toFloat(),
                scale = m.optDouble("scale", 0.4).toFloat(), rotation = m.optDouble("rot", 0.0).toFloat(),
                opacity = m.optDouble("op", 1.0).toFloat(), visible = m.optBoolean("vis", true),
                locked = m.optBoolean("lock", false), animIn = m.optString("animIn", "FADE"),
                animOut = m.optString("animOut", "FADE"), animMs = m.optLong("animMs", 400), z = m.optInt("z", 0),
            )
        }
        return Project(o.getString("id"), o.getString("name"), clips, texts, audios, images, o.optLong("updated"))
    }
}
