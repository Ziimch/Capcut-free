package com.freeeditor

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

data class Clip(
    val id: String = UUID.randomUUID().toString(),
    val uri: String,
    val inMs: Long,
    val outMs: Long,
    val sourceMs: Long,
    val width: Int = 0,
    val height: Int = 0,
    val volume: Float = 1f,
) { val durationMs: Long get() = outMs - inMs }

data class AudioClip(
    val id: String = UUID.randomUUID().toString(),
    val uri: String,
    val name: String = "Audio",
    val startMs: Long,            // position on the timeline
    val inMs: Long,               // trim inside the source file
    val outMs: Long,
    val sourceMs: Long,
    val volume: Float = 1f,
    val fadeInMs: Long = 0,
    val fadeOutMs: Long = 0,
) {
    val durationMs: Long get() = outMs - inMs
    val endMs: Long get() = startMs + durationMs
}

data class TextItem(
    val id: String = UUID.randomUUID().toString(),
    val text: String = "Your text",
    val startMs: Long,
    val durationMs: Long = 3000,
    val x: Float = 0.5f,          // center, fraction of frame width
    val y: Float = 0.5f,          // center, fraction of frame height
    val size: Float = 0.07f,      // font size as fraction of frame height
    val color: Int = 0xFFFFFFFF.toInt(),
    val font: String = "SANS",    // SANS, SERIF, MONO, CURSIVE, CONDENSED
    val bold: Boolean = true,
    val italic: Boolean = false,
    val outline: Boolean = false,
    val shadow: Boolean = true,
    val animIn: String = "FADE",  // NONE, FADE, SLIDE, POP
    val animOut: String = "FADE",
    val animMs: Long = 400,
    val rotation: Float = 0f,     // degrees
    val scale: Float = 1f,        // multiplier on top of font size
    val opacity: Float = 1f,
    val visible: Boolean = true,
    val locked: Boolean = false,
    val name: String = "",
    val z: Int = 0,               // stacking order, higher = on top
    val kfs: List<Keyframe> = emptyList(),
)

data class ImageLayer(
    val id: String = UUID.randomUUID().toString(),
    val uri: String,
    val name: String = "Image",
    val startMs: Long,
    val durationMs: Long = 3000,
    val x: Float = 0.5f,
    val y: Float = 0.5f,
    val scale: Float = 0.4f,      // width as fraction of the frame width
    val rotation: Float = 0f,
    val opacity: Float = 1f,
    val visible: Boolean = true,
    val locked: Boolean = false,
    val animIn: String = "FADE",
    val animOut: String = "FADE",
    val animMs: Long = 400,
    val z: Int = 0,
    val kfs: List<Keyframe> = emptyList(),
)

data class ShapeLayer(
    val id: String = UUID.randomUUID().toString(),
    val kind: String,             // RECT, ELLIPSE, TRIANGLE, POLYGON, STAR, HEART, LINE, PATH
    val name: String = "Shape",
    val startMs: Long,
    val durationMs: Long = 3000,
    val x: Float = 0.5f,
    val y: Float = 0.5f,
    val w: Float = 0.3f,          // width as fraction of frame width
    val h: Float = 0.3f,          // height as fraction of frame WIDTH (keeps proportions stable)
    val scale: Float = 1f,
    val rotation: Float = 0f,
    val opacity: Float = 1f,
    val visible: Boolean = true,
    val locked: Boolean = false,
    val animIn: String = "FADE",
    val animOut: String = "FADE",
    val animMs: Long = 400,
    val z: Int = 0,
    val hasFill: Boolean = true,
    val fillColor: Int = 0xFF4DD0E1.toInt(),
    val fillColor2: Int = 0xFFFF2D95.toInt(),
    val gradient: Boolean = false,
    val gradAngle: Float = 0f,
    val strokeColor: Int = 0xFFFFFFFF.toInt(),
    val strokeW: Float = 0f,      // fraction of frame width
    val corner: Float = 0.1f,
    val sides: Int = 5,
    val inner: Float = 0.45f,
    val trim: Float = 1f,         // stroke trim-path (0..1), keyframable
    val pts: List<Float> = emptyList(), // PATH: x0,y0,x1,y1... normalized to the shape box
    val kfs: List<Keyframe> = emptyList(),
)

data class Project(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val clips: List<Clip> = emptyList(),
    val texts: List<TextItem> = emptyList(),
    val audios: List<AudioClip> = emptyList(),
    val images: List<ImageLayer> = emptyList(),
    val shapes: List<ShapeLayer> = emptyList(),
    val updatedAt: Long = System.currentTimeMillis(),
)

private fun kfsToJson(l: List<Keyframe>): JSONArray {
    val a = JSONArray()
    l.forEach { a.put(JSONObject().put("p", it.prop).put("t", it.tMs).put("v", it.value.toDouble())
        .put("c", JSONArray(it.c.map { f -> f.toDouble() }))) }
    return a
}

private fun kfsFromJson(a: JSONArray?): List<Keyframe> {
    if (a == null) return emptyList()
    return (0 until a.length()).map {
        val o = a.getJSONObject(it); val c = o.getJSONArray("c")
        Keyframe(o.getString("p"), o.getLong("t"), o.getDouble("v").toFloat(), (0 until 4).map { i -> c.getDouble(i).toFloat() })
    }
}

private fun shapesJson(l: List<ShapeLayer>): JSONArray {
    val a = JSONArray()
    l.forEach {
        a.put(JSONObject().put("id", it.id).put("kind", it.kind).put("name", it.name).put("start", it.startMs)
            .put("dur", it.durationMs).put("x", it.x.toDouble()).put("y", it.y.toDouble()).put("w", it.w.toDouble())
            .put("h", it.h.toDouble()).put("scale", it.scale.toDouble()).put("rot", it.rotation.toDouble())
            .put("op", it.opacity.toDouble()).put("vis", it.visible).put("lock", it.locked)
            .put("animIn", it.animIn).put("animOut", it.animOut).put("animMs", it.animMs).put("z", it.z)
            .put("fill", it.hasFill).put("fc", it.fillColor).put("fc2", it.fillColor2).put("grad", it.gradient)
            .put("ga", it.gradAngle.toDouble()).put("sc", it.strokeColor).put("sw", it.strokeW.toDouble())
            .put("corner", it.corner.toDouble()).put("sides", it.sides).put("inner", it.inner.toDouble())
            .put("trim", it.trim.toDouble()).put("pts", JSONArray(it.pts.map { f -> f.toDouble() }))
            .put("kf", kfsToJson(it.kfs)))
    }
    return a
}

private fun shapesFromJson(a: JSONArray?): List<ShapeLayer> {
    if (a == null) return emptyList()
    return (0 until a.length()).map {
        val o = a.getJSONObject(it)
        val pa = o.optJSONArray("pts") ?: JSONArray()
        ShapeLayer(
            id = o.getString("id"), kind = o.getString("kind"), name = o.optString("name", "Shape"),
            startMs = o.getLong("start"), durationMs = o.getLong("dur"),
            x = o.getDouble("x").toFloat(), y = o.getDouble("y").toFloat(),
            w = o.getDouble("w").toFloat(), h = o.getDouble("h").toFloat(),
            scale = o.optDouble("scale", 1.0).toFloat(), rotation = o.optDouble("rot", 0.0).toFloat(),
            opacity = o.optDouble("op", 1.0).toFloat(), visible = o.optBoolean("vis", true), locked = o.optBoolean("lock", false),
            animIn = o.optString("animIn", "FADE"), animOut = o.optString("animOut", "FADE"), animMs = o.optLong("animMs", 400),
            z = o.optInt("z", 0), hasFill = o.optBoolean("fill", true), fillColor = o.optInt("fc", 0xFF4DD0E1.toInt()),
            fillColor2 = o.optInt("fc2", 0xFFFF2D95.toInt()), gradient = o.optBoolean("grad", false),
            gradAngle = o.optDouble("ga", 0.0).toFloat(), strokeColor = o.optInt("sc", 0xFFFFFFFF.toInt()),
            strokeW = o.optDouble("sw", 0.0).toFloat(), corner = o.optDouble("corner", 0.1).toFloat(),
            sides = o.optInt("sides", 5), inner = o.optDouble("inner", 0.45).toFloat(), trim = o.optDouble("trim", 1.0).toFloat(),
            pts = (0 until pa.length()).map { i -> pa.getDouble(i).toFloat() },
            kfs = kfsFromJson(o.optJSONArray("kf")),
        )
    }
}

class ProjectStore(context: Context) {
    private val dir = File(context.filesDir, "projects").apply { mkdirs() }

    fun save(p: Project) {
        val clips = JSONArray()
        p.clips.forEach {
            clips.put(JSONObject().put("id", it.id).put("uri", it.uri)
                .put("in", it.inMs).put("out", it.outMs).put("src", it.sourceMs)
                .put("w", it.width).put("h", it.height).put("vol", it.volume.toDouble()))
        }
        val texts = JSONArray()
        p.texts.forEach {
            texts.put(JSONObject().put("id", it.id).put("text", it.text).put("start", it.startMs)
                .put("dur", it.durationMs).put("x", it.x.toDouble()).put("y", it.y.toDouble())
                .put("size", it.size.toDouble()).put("color", it.color).put("font", it.font)
                .put("bold", it.bold).put("italic", it.italic).put("outline", it.outline)
                .put("shadow", it.shadow).put("animIn", it.animIn).put("animOut", it.animOut)
                .put("animMs", it.animMs).put("rot", it.rotation.toDouble()).put("scale", it.scale.toDouble())
                .put("op", it.opacity.toDouble()).put("vis", it.visible).put("lock", it.locked)
                .put("tname", it.name).put("z", it.z).put("kf", kfsToJson(it.kfs)))
        }
        val images = JSONArray()
        p.images.forEach {
            images.put(JSONObject().put("id", it.id).put("uri", it.uri).put("name", it.name)
                .put("start", it.startMs).put("dur", it.durationMs).put("x", it.x.toDouble()).put("y", it.y.toDouble())
                .put("scale", it.scale.toDouble()).put("rot", it.rotation.toDouble()).put("op", it.opacity.toDouble())
                .put("vis", it.visible).put("lock", it.locked).put("animIn", it.animIn).put("animOut", it.animOut)
                .put("animMs", it.animMs).put("z", it.z).put("kf", kfsToJson(it.kfs)))
        }
        val audios = JSONArray()
        p.audios.forEach {
            audios.put(JSONObject().put("id", it.id).put("uri", it.uri).put("name", it.name)
                .put("start", it.startMs).put("in", it.inMs).put("out", it.outMs).put("src", it.sourceMs)
                .put("vol", it.volume.toDouble()).put("fi", it.fadeInMs).put("fo", it.fadeOutMs))
        }
        val o = JSONObject().put("id", p.id).put("name", p.name)
            .put("updated", System.currentTimeMillis()).put("clips", clips).put("texts", texts).put("audios", audios).put("images", images).put("shapes", shapesJson(p.shapes))
        val tmp = File(dir, "${p.id}.tmp")
        tmp.writeText(o.toString())
        tmp.renameTo(File(dir, "${p.id}.json"))
    }

    fun loadAll(): List<Project> = (dir.listFiles { f -> f.extension == "json" } ?: emptyArray())
        .mapNotNull { runCatching { parse(it.readText()) }.getOrNull() }
        .sortedByDescending { it.updatedAt }

    fun delete(id: String) { File(dir, "$id.json").delete() }

    private fun parse(s: String): Project {
        val o = JSONObject(s)
        val a = o.getJSONArray("clips")
        val clips = (0 until a.length()).map {
            val c = a.getJSONObject(it)
            Clip(c.getString("id"), c.getString("uri"), c.getLong("in"), c.getLong("out"), c.getLong("src"),
                c.optInt("w", 0), c.optInt("h", 0), c.optDouble("vol", 1.0).toFloat())
        }
        val ta = o.optJSONArray("texts") ?: JSONArray()
        val texts = (0 until ta.length()).map {
            val t = ta.getJSONObject(it)
            TextItem(
                id = t.getString("id"), text = t.getString("text"), startMs = t.getLong("start"),
                durationMs = t.getLong("dur"), x = t.getDouble("x").toFloat(), y = t.getDouble("y").toFloat(),
                size = t.getDouble("size").toFloat(), color = t.getInt("color"), font = t.getString("font"),
                bold = t.getBoolean("bold"), italic = t.getBoolean("italic"), outline = t.getBoolean("outline"),
                shadow = t.getBoolean("shadow"), animIn = t.getString("animIn"), animOut = t.getString("animOut"),
                animMs = t.getLong("animMs"),
                rotation = t.optDouble("rot", 0.0).toFloat(), scale = t.optDouble("scale", 1.0).toFloat(),
                opacity = t.optDouble("op", 1.0).toFloat(), visible = t.optBoolean("vis", true),
                locked = t.optBoolean("lock", false), name = t.optString("tname", ""), z = t.optInt("z", 0),
                kfs = kfsFromJson(t.optJSONArray("kf")),
            )
        }
        val aa = o.optJSONArray("audios") ?: JSONArray()
        val audios = (0 until aa.length()).map {
            val a = aa.getJSONObject(it)
            AudioClip(a.getString("id"), a.getString("uri"), a.optString("name", "Audio"), a.getLong("start"),
                a.getLong("in"), a.getLong("out"), a.getLong("src"), a.optDouble("vol", 1.0).toFloat(),
                a.optLong("fi", 0), a.optLong("fo", 0))
        }
        val ia = o.optJSONArray("images") ?: JSONArray()
        val images = (0 until ia.length()).map {
            val m = ia.getJSONObject(it)
            ImageLayer(
                id = m.getString("id"), uri = m.getString("uri"), name = m.optString("name", "Image"),
                startMs = m.getLong("start"), durationMs = m.getLong("dur"),
                x = m.getDouble("x").toFloat(), y = m.getDouble("y").toFloat(),
                scale = m.optDouble("scale", 0.4).toFloat(), rotation = m.optDouble("rot", 0.0).toFloat(),
                opacity = m.optDouble("op", 1.0).toFloat(), visible = m.optBoolean("vis", true),
                locked = m.optBoolean("lock", false), animIn = m.optString("animIn", "FADE"),
                animOut = m.optString("animOut", "FADE"), animMs = m.optLong("animMs", 400), z = m.optInt("z", 0),
                kfs = kfsFromJson(m.optJSONArray("kf")),
            )
        }
        return Project(o.getString("id"), o.getString("name"), clips, texts, audios, images,
            shapesFromJson(o.optJSONArray("shapes")), o.optLong("updated"))
    }
}
