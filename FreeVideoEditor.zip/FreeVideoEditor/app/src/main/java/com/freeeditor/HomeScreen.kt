package com.freeeditor

import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.text.DateFormat
import java.util.Date

/** Preview thumbnail of a project: a frame from its first clip. */
@Composable
private fun ProjectThumb(p: Project) {
    val ctx = LocalContext.current
    val first = p.clips.firstOrNull()
    val bmp by produceState<Bitmap?>(null, first?.uri, first?.inMs) {
        val c = first ?: return@produceState
        value = withContext(Dispatchers.IO) {
            val key = "home|${c.uri}|${c.inMs}"
            ThumbCache.cache.get(key) ?: runCatching {
                val r = MediaMetadataRetriever()
                try {
                    r.setDataSource(ctx, Uri.parse(c.uri))
                    r.getFrameAtTime(c.inMs * 1000, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)?.let { f ->
                        Bitmap.createScaledBitmap(f, 200, (200f * f.height / f.width).toInt().coerceAtLeast(1), true)
                    }
                } finally { r.release() }
            }.getOrNull()?.also { ThumbCache.cache.put(key, it) }
        }
    }
    Box(Modifier.size(76.dp).clip(RoundedCornerShape(12.dp)).background(MaterialTheme.colorScheme.background), contentAlignment = Alignment.Center) {
        val b = bmp
        if (b != null) Image(b.asImageBitmap(), null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
        else Icon(Icons.Default.Movie, null)
    }
}

@Composable
fun HomeScreen(projects: List<Project>, onNew: () -> Unit, onOpen: (Project) -> Unit, onDelete: (Project) -> Unit) {
    Column(Modifier.fillMaxSize().statusBarsPadding().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("KitCut", style = MaterialTheme.typography.headlineMedium)
                Text("No watermark. No ads. No account.  v${BuildConfig.VERSION_NAME}",
                    style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
            }
            UpdateButton()
        }
        Spacer(Modifier.height(16.dp))
        Button(onClick = onNew, modifier = Modifier.fillMaxWidth().height(56.dp), shape = RoundedCornerShape(16.dp)) {
            Icon(Icons.Default.Add, null); Spacer(Modifier.width(8.dp)); Text("New project")
        }
        Spacer(Modifier.height(16.dp))
        Text("Recent projects", style = MaterialTheme.typography.titleMedium)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 8.dp)) {
            items(projects, key = { it.id }) { p ->
                Surface(shape = RoundedCornerShape(16.dp), color = MaterialTheme.colorScheme.surface,
                    modifier = Modifier.fillMaxWidth().clickable { onOpen(p) }) {
                    Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        ProjectThumb(p)
                        Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                            Text(p.name, style = MaterialTheme.typography.titleMedium, maxLines = 1)
                            val secs = (p.clips.sumOf { it.durationMs } / 1000).toInt()
                            Text("${fmtShort(secs)}  ·  ${p.clips.size} clips", style = MaterialTheme.typography.bodySmall)
                            Text(DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT).format(Date(p.updatedAt)),
                                style = MaterialTheme.typography.labelSmall)
                        }
                        IconButton(onClick = { onDelete(p) }) { Icon(Icons.Default.Delete, "Delete") }
                    }
                }
            }
        }
    }
}
