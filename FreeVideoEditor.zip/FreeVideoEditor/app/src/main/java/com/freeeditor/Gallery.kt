package com.freeeditor

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.core.content.FileProvider
import java.io.File

object Gallery {
    /** Copies an exported video into Movies/KitCut. Returns its content Uri, or null on Android 9 and below. */
    fun saveVideo(ctx: Context, f: File): Uri? {
        if (Build.VERSION.SDK_INT < 29) return null
        return runCatching {
            val v = ContentValues()
            v.put(MediaStore.Video.Media.DISPLAY_NAME, f.name)
            v.put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            v.put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/KitCut")
            v.put(MediaStore.Video.Media.IS_PENDING, 1)
            val r = ctx.contentResolver
            val uri = r.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, v)
            if (uri == null) null else {
                r.openOutputStream(uri)?.use { o -> f.inputStream().use { it.copyTo(o) } }
                val done = ContentValues(); done.put(MediaStore.Video.Media.IS_PENDING, 0)
                r.update(uri, done, null, null)
                uri
            }
        }.getOrNull()
    }

    /** Saves a PNG into Pictures/KitCut (Android 10+). */
    fun saveImage(ctx: Context, bmp: Bitmap): Uri? {
        if (Build.VERSION.SDK_INT < 29) return null
        return runCatching {
            val v = ContentValues()
            v.put(MediaStore.Images.Media.DISPLAY_NAME, "KitCut_${System.currentTimeMillis()}.png")
            v.put(MediaStore.Images.Media.MIME_TYPE, "image/png")
            v.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/KitCut")
            v.put(MediaStore.Images.Media.IS_PENDING, 1)
            val r = ctx.contentResolver
            val uri = r.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v)
            if (uri == null) null else {
                r.openOutputStream(uri)?.use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
                val done = ContentValues(); done.put(MediaStore.Images.Media.IS_PENDING, 0)
                r.update(uri, done, null, null)
                uri
            }
        }.getOrNull()
    }

    fun fileUri(ctx: Context, f: File): Uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", f)

    fun share(ctx: Context, uri: Uri, mime: String) {
        val i = Intent(Intent.ACTION_SEND)
        i.type = mime
        i.putExtra(Intent.EXTRA_STREAM, uri)
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        val chooser = Intent.createChooser(i, "Share")
        chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        runCatching { ctx.startActivity(chooser) }
    }
}
