package com.freeeditor

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.net.Uri
import android.util.LruCache
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.media3.effect.BitmapOverlay
import kotlin.math.max
import kotlin.math.roundToInt

// ---------- Animation shared by every overlay layer ----------
class AnimState(val alpha: Float, val dy: Float, val scale: Float)

fun animState(animIn: String, animOut: String, animMs: Long, start: Long, dur: Long, ms: Long, h: Int): AnimState {
    val a = minOf(animMs, dur / 2).coerceAtLeast(1).toFloat()
    val tin = if (animIn == "NONE") 1f else ((ms - start) / a).coerceIn(0f, 1f)
    val tout = if (animOut == "NONE") 1f else ((start + dur - ms) / a).coerceIn(0f, 1f)
    var alpha = 1f; var dy = 0f; var scale = 1f
    when (animIn) {
        "FADE" -> alpha *= tin
        "SLIDE" -> { alpha *= tin; dy += (1f - tin) * 0.06f * h }
        "POP" -> { alpha *= tin; scale *= 0.5f + 0.5f * tin }
    }
    when (animOut) {
        "FADE" -> alpha *= tout
        "SLIDE" -> { alpha *= tout; dy -= (1f - tout) * 0.06f * h }
        "POP" -> { alpha *= tout; scale *= 0.5f + 0.5f * tout }
    }
    return AnimState(alpha, dy, scale)
}

fun isAnimating(animIn: String, animOut: String, animMs: Long, start: Long, dur: Long, ms: Long): Boolean {
    val a = minOf(animMs, dur / 2).coerceAtLeast(1)
    return (animIn != "NONE" && ms - start < a) || (animOut != "NONE" && start + dur - ms < a)
}

// ---------- Image cache ----------
object ImageCache {
    private val cache = object : LruCache<String, Bitmap>(48 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }
    fun peek(uri: String): Bitmap? = cache.get(uri)
    fun get(ctx: Context, uri: String): Bitmap? {
        cache.get(uri)?.let { return it }
        val b = load(ctx, uri) ?: return null
        cache.put(uri, b); return b
    }
    private fun load(ctx: Context, uri: String): Bitmap? = runCatching {
        val u = Uri.parse(uri)
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        ctx.contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var s = 1
        while (max(bounds.outWidth, bounds.outHeight) / s > 1600) s *= 2
        val o = BitmapFactory.Options().apply { inSampleSize = s }
        val bmp = ctx.contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it, null, o) } ?: return@runCatching null
        val orient = ctx.contentResolver.openInputStream(u)?.use {
            runCatching { android.media.ExifInterface(it).getAttributeInt(android.media.ExifInterface.TAG_ORIENTATION, 1) }.getOrDefault(1)
        } ?: 1
        val m = android.graphics.Matrix()
        when (orient) {
            6 -> m.postRotate(90f); 3 -> m.postRotate(180f); 8 -> m.postRotate(270f)
            2 -> m.postScale(-1f, 1f); 4 -> m.postScale(1f, -1f)
        }
        if (m.isIdentity) bmp else Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
    }.getOrNull()
}

// ---------- One renderer for all overlay layers (preview + export) ----------
object LayerRender {
    private fun active(start: Long, dur: Long, ms: Long) = ms >= start && ms < start + dur

    fun activeTexts(texts: List<TextItem>, ms: Long) = texts.filter { it.visible && active(it.startMs, it.durationMs, ms) }
    fun activeImages(images: List<ImageLayer>, ms: Long) = images.filter { it.visible && active(it.startMs, it.durationMs, ms) }

    fun activeShapes(shapes: List<ShapeLayer>, ms: Long) = shapes.filter { it.visible && active(it.startMs, it.durationMs, ms) }

    fun draw(canvas: Canvas, w: Int, h: Int, texts: List<TextItem>, images: List<ImageLayer>, shapes: List<ShapeLayer>, ms: Long, clips: List<Clip>, bitmap: (String) -> Bitmap?) {
        clipAt(clips, ms)?.let { if (it.fx.vignette > 0.01f) FxRender.vignette(canvas, w, h, it.fx.vignette) }
        val all = ArrayList<Pair<Int, Any>>()
        activeTexts(texts, ms).forEach { all.add(it.z to it) }
        activeImages(images, ms).forEach { all.add(it.z to it) }
        activeShapes(shapes, ms).forEach { all.add(it.z to it) }
        all.sortBy { it.first }
        for ((_, o) in all) {
            val fx = when (o) { is TextItem -> o.fx; is ImageLayer -> o.fx; is ShapeLayer -> o.fx; else -> LayerFx() }
            if (fx.isNone || w <= 0 || h <= 0) { drawOne(canvas, w, h, o, ms, bitmap); continue }
            val tmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            drawOne(Canvas(tmp), w, h, o, ms, bitmap)
            FxRender.composite(canvas, tmp, fx)
            tmp.recycle()
        }
    }

    private fun drawOne(canvas: Canvas, w: Int, h: Int, o: Any, ms: Long, bitmap: (String) -> Bitmap?) {
        when (o) {
            is TextItem -> TextRender.drawText(canvas, w, h, o, ms)
            is ImageLayer -> drawImage(canvas, w, h, o, ms, bitmap(o.uri))
            is ShapeLayer -> ShapeRender.draw(canvas, w, h, o, ms)
        }
    }

    private fun drawImage(canvas: Canvas, w: Int, h: Int, im: ImageLayer, ms: Long, bmp: Bitmap?) {
        if (bmp == null) return
        val st = animState(im.animIn, im.animOut, im.animMs, im.startMs, im.durationMs, ms, h)
        val xf = xformOf(im.kfs, (ms - im.startMs).coerceAtLeast(0), im.x, im.y, im.scale, im.rotation, im.opacity)
        val alpha = st.alpha * xf.op
        if (alpha <= 0.01f) return
        val tw = xf.scale * w
        val th = tw * bmp.height / bmp.width
        val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply { this.alpha = (255 * alpha).toInt() }
        canvas.save()
        canvas.translate(xf.x * w, xf.y * h + st.dy)
        canvas.rotate(xf.rot)
        canvas.scale(st.scale, st.scale)
        canvas.drawBitmap(bmp, null, RectF(-tw / 2, -th / 2, tw / 2, th / 2), paint)
        canvas.restore()
    }
}

/** Full-frame transparent overlay for the Media3 exporter. */
class LayerBitmapOverlay(
    private val ctx: Context, private val w: Int, private val h: Int,
    private val texts: List<TextItem>, private val images: List<ImageLayer>, private val shapes: List<ShapeLayer>,
    private val clips: List<Clip>,
) : BitmapOverlay() {
    private var lastKey: String? = null
    private var lastBmp: Bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)

    override fun getBitmap(presentationTimeUs: Long): Bitmap {
        val ms = presentationTimeUs / 1000
        val t = LayerRender.activeTexts(texts, ms); val i = LayerRender.activeImages(images, ms); val sh = LayerRender.activeShapes(shapes, ms)
        val vk = clipAt(clips, ms)?.let { if (it.fx.vignette > 0.01f) it.id else "-" } ?: "-"
        val key = if (t.isEmpty() && i.isEmpty() && sh.isEmpty() && vk == "-") "empty" else vk + "#" +
            t.joinToString("|") { if (it.kfs.isNotEmpty() || isAnimating(it.animIn, it.animOut, it.animMs, it.startMs, it.durationMs, ms)) "${it.id}@${ms / 40}" else it.id } + "#" +
                i.joinToString("|") { if (it.kfs.isNotEmpty() || isAnimating(it.animIn, it.animOut, it.animMs, it.startMs, it.durationMs, ms)) "${it.id}@${ms / 40}" else it.id } + "#" +
                sh.joinToString("|") { if (it.kfs.isNotEmpty() || isAnimating(it.animIn, it.animOut, it.animMs, it.startMs, it.durationMs, ms)) "${it.id}@${ms / 40}" else it.id }
        if (key != lastKey) {
            val b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            LayerRender.draw(Canvas(b), w, h, t, i, sh, ms, clips) { ImageCache.get(ctx, it) }
            lastBmp = b; lastKey = key
        }
        return lastBmp
    }
}

// ---------- UI pieces ----------
@Composable
fun TransformControls(
    opacity: Float, rotation: Float, scale: Float, scaleRange: ClosedFloatingPointRange<Float>,
    onOpacity: (Float) -> Unit, onRotation: (Float) -> Unit, onScale: (Float) -> Unit,
) {
    Text("Opacity ${(opacity * 100).roundToInt()}%", style = MaterialTheme.typography.labelSmall)
    Slider(value = opacity.coerceIn(0f, 1f), onValueChange = onOpacity, valueRange = 0f..1f)
    val rot = ((rotation % 360f) + 360f) % 360f
    Text("Rotation ${rot.roundToInt()} deg", style = MaterialTheme.typography.labelSmall)
    Slider(value = rot, onValueChange = onRotation, valueRange = 0f..360f)
    Text("Scale ${"%.2f".format(scale)}", style = MaterialTheme.typography.labelSmall)
    Slider(value = scale.coerceIn(scaleRange), onValueChange = onScale, valueRange = scaleRange)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ImagePanel(img: ImageLayer, total: Long, kf: KfHandlers, onUpdate: (ImageLayer, Boolean) -> Unit) {
    Column(Modifier.fillMaxWidth().heightIn(max = 170.dp).verticalScroll(rememberScrollState()).padding(horizontal = 12.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(img.name, style = MaterialTheme.typography.titleSmall, maxLines = 1)
        KeyframeControls(img.startMs, img.durationMs, img.kfs, img.x, img.y, img.scale, img.rotation, img.opacity, 0.05f..1.5f, kf)
        Text("Animation in", style = MaterialTheme.typography.labelSmall)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            ANIMS.forEach { a -> Chip(a.lowercase().replaceFirstChar { it.uppercase() }, img.animIn == a) { onUpdate(img.copy(animIn = a), true) } }
        }
        Text("Animation out", style = MaterialTheme.typography.labelSmall)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            ANIMS.forEach { a -> Chip(a.lowercase().replaceFirstChar { it.uppercase() }, img.animOut == a) { onUpdate(img.copy(animOut = a), true) } }
        }
        if (total > 0) {
            val st = img.startMs.coerceIn(0, total)
            val en = (img.startMs + img.durationMs).coerceIn(st, total)
            var range by remember(img.id, img.startMs, img.durationMs) { mutableStateOf(st.toFloat()..en.toFloat()) }
            Text("Timing: ${fmt(range.start.toLong())} - ${fmt(range.endInclusive.toLong())}", style = MaterialTheme.typography.labelSmall)
            RangeSlider(value = range, onValueChange = { range = it }, valueRange = 0f..total.toFloat(),
                onValueChangeFinished = {
                    val a = range.start.toLong(); val b = range.endInclusive.toLong()
                    if (b - a >= 300) onUpdate(img.copy(startMs = a, durationMs = b - a), true)
                })
        }
        LayerFxControls(img.fx) { nf, rec -> onUpdate(img.copy(fx = nf), rec) }
        Spacer(Modifier.height(6.dp))
    }
}

class LayerRow(val id: String, val kind: String, val name: String, val visible: Boolean, val locked: Boolean)

@Composable
fun LayersPanel(
    rows: List<LayerRow>, selectedId: String?,
    onSelect: (String) -> Unit, onVisible: (String) -> Unit, onLock: (String) -> Unit,
    onMove: (String, Int) -> Unit, onDelete: (String) -> Unit, onRename: (String, String) -> Unit,
) {
    var renaming by remember { mutableStateOf<LayerRow?>(null) }
    var newName by remember { mutableStateOf("") }
    Column(Modifier.fillMaxWidth().heightIn(max = 170.dp).verticalScroll(rememberScrollState()).padding(horizontal = 8.dp)) {
        Text("Layers (top first)", style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(start = 4.dp))
        if (rows.isEmpty()) Text("No layers yet. Tap + and add Text, an Image or a Shape.", Modifier.padding(8.dp), style = MaterialTheme.typography.bodySmall)
        rows.forEach { r ->
            val sel = r.id == selectedId
            Surface(
                color = if (sel) MaterialTheme.colorScheme.primary.copy(alpha = 0.18f) else MaterialTheme.colorScheme.surface,
                shape = androidx.compose.foundation.shape.RoundedCornerShape(10.dp),
                modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp).clickable { onSelect(r.id) }
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(when (r.kind) { "T" -> Icons.Default.TextFields; "I" -> Icons.Default.Image; else -> Icons.Default.Star }, null, Modifier.padding(start = 8.dp).size(20.dp))
                    Text(r.name, Modifier.weight(1f).padding(horizontal = 8.dp), maxLines = 1, style = MaterialTheme.typography.bodyMedium)
                    IconButton(onClick = { renaming = r; newName = r.name }, Modifier.size(34.dp)) { Icon(Icons.Default.Edit, "Rename", Modifier.size(18.dp)) }
                    IconButton(onClick = { onVisible(r.id) }, Modifier.size(34.dp)) {
                        Icon(if (r.visible) Icons.Default.Visibility else Icons.Default.VisibilityOff, "Show/hide", Modifier.size(18.dp))
                    }
                    IconButton(onClick = { onLock(r.id) }, Modifier.size(34.dp)) {
                        Icon(if (r.locked) Icons.Default.Lock else Icons.Default.LockOpen, "Lock", Modifier.size(18.dp))
                    }
                    IconButton(onClick = { onMove(r.id, 1) }, Modifier.size(34.dp)) { Icon(Icons.Default.KeyboardArrowUp, "Up", Modifier.size(20.dp)) }
                    IconButton(onClick = { onMove(r.id, -1) }, Modifier.size(34.dp)) { Icon(Icons.Default.KeyboardArrowDown, "Down", Modifier.size(20.dp)) }
                    IconButton(onClick = { onDelete(r.id) }, Modifier.size(34.dp)) { Icon(Icons.Default.Delete, "Delete", Modifier.size(18.dp)) }
                }
            }
        }
        Spacer(Modifier.height(6.dp))
    }
    renaming?.let { r ->
        AlertDialog(
            onDismissRequest = { renaming = null },
            confirmButton = { TextButton(onClick = { onRename(r.id, newName); renaming = null }) { Text("OK") } },
            dismissButton = { TextButton(onClick = { renaming = null }) { Text("Cancel") } },
            title = { Text("Rename layer") },
            text = { OutlinedTextField(value = newName, onValueChange = { newName = it }, singleLine = true) },
        )
    }
}
