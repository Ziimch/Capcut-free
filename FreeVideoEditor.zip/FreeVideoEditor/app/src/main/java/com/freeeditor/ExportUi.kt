package com.freeeditor

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun ExportDialog(p: Project, onChange: (Project) -> Unit, onExport: () -> Unit, onFrame: () -> Unit, onDismiss: () -> Unit) {
    val (w, h) = canvasSize(p)
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Export") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Canvas ratio", style = MaterialTheme.typography.labelSmall)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("ORIGINAL", "9:16", "16:9", "1:1", "4:5").forEach { r ->
                        Chip(if (r == "ORIGINAL") "Original" else r, p.ratio == r) { onChange(p.copy(ratio = r)) }
                    }
                }
                Text("Video in canvas", style = MaterialTheme.typography.labelSmall)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Chip("Fit (bars)", p.fit) { onChange(p.copy(fit = true)) }
                    Chip("Fill (crop)", !p.fit) { onChange(p.copy(fit = false)) }
                }
                Text("Resolution", style = MaterialTheme.typography.labelSmall)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(480, 720, 1080).forEach { r -> Chip("${r}p", p.exportRes == r) { onChange(p.copy(exportRes = r)) } }
                }
                Text("Bitrate", style = MaterialTheme.typography.labelSmall)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(0, 4, 8, 16).forEach { b -> Chip(if (b == 0) "Auto" else "$b Mbps", p.exportMbps == b) { onChange(p.copy(exportMbps = b)) } }
                }
                Text("Codec", style = MaterialTheme.typography.labelSmall)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Chip("H.264", !p.hevc) { onChange(p.copy(hevc = false)) }
                    Chip("H.265", p.hevc) { onChange(p.copy(hevc = true)) }
                }
                Text("Output: ${w} x ${h}", style = MaterialTheme.typography.labelSmall)
            }
        },
        confirmButton = { TextButton(onClick = onExport) { Text("Export video") } },
        dismissButton = {
            Row {
                TextButton(onClick = onFrame) { Text("Frame PNG") }
                TextButton(onClick = onDismiss) { Text("Cancel") }
            }
        },
    )
}
