package com.freeeditor

import android.content.Context
import android.net.Uri
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import kotlin.math.abs

/** Plays the audio clips in sync with the main preview, applying volume and fades live. */
class AudioPreview(private val ctx: Context) {
    private val players = HashMap<String, ExoPlayer>()
    private val loaded = HashMap<String, String>()
    private val active = HashSet<String>()

    fun sync(audios: List<AudioClip>, playheadMs: Long, playing: Boolean) {
        val ids = audios.map { it.id }.toSet()
        players.keys.filter { it !in ids }.forEach { id ->
            players.remove(id)?.release(); loaded.remove(id); active.remove(id)
        }
        for (a in audios) {
            val isActive = playing && playheadMs >= a.startMs && playheadMs < a.endMs
            val p = players[a.id]
            if (!isActive) { p?.pause(); active.remove(a.id); continue }
            val pl = p ?: ExoPlayer.Builder(ctx).build().also { players[a.id] = it }
            val sig = "${a.uri}|${a.inMs}|${a.outMs}"
            val want = playheadMs - a.startMs
            if (loaded[a.id] != sig) {
                pl.setMediaItem(MediaItem.Builder().setUri(Uri.parse(a.uri)).setClippingConfiguration(
                    MediaItem.ClippingConfiguration.Builder().setStartPositionMs(a.inMs).setEndPositionMs(a.outMs).build()).build())
                pl.prepare(); loaded[a.id] = sig; active.remove(a.id)
            }
            if (active.add(a.id)) pl.seekTo(want)
            else if (pl.playbackState == androidx.media3.common.Player.STATE_READY && abs(pl.currentPosition - want) > 300) pl.seekTo(want)
            var g = a.volume
            if (a.fadeInMs > 0) g *= (want.toFloat() / a.fadeInMs).coerceIn(0f, 1f)
            if (a.fadeOutMs > 0) g *= ((a.durationMs - want).toFloat() / a.fadeOutMs).coerceIn(0f, 1f)
            pl.volume = g
            pl.playWhenReady = true
        }
    }

    fun pauseAll() { players.values.forEach { it.pause() }; active.clear() }
    fun release() { players.values.forEach { it.release() }; players.clear(); loaded.clear(); active.clear() }
}
