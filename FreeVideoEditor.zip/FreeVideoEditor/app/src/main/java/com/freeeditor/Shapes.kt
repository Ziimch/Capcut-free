package com.freeeditor

import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PathMeasure
import android.graphics.RectF
import android.graphics.Shader
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.roundToInt
import kotlin.math.sin

val SHAPE_KINDS = listOf("RECT", "ELLIPSE", "TRIANGLE", "POLYGON", "STAR", "HEART", "LINE")

/** Draws vector shape layers. Used by the live preview and the exporter. */
object ShapeRender {
    private fun polygon(p: Path, n: Int, hw: Float, hh: Float) {
        val k = max(3, n)
        for (i in 0 until k) {
            val a = -PI / 2 + 2 * PI * i / k
            val x = (cos(a) * hw).toFloat(); val y = (sin(a) * hh).toFloat()
            if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
        }
        p.close()
    }

    private fun star(p: Path, n: Int, inner: Float, hw: Float, hh: Float) {
        val k = max(3, n)
        for (i in 0 until 2 * k) {
            val r = if (i % 2 == 0) 1f else inner
            val a = -PI / 2 + PI * i / k
            val x = (cos(a) * hw * r).toFloat(); val y = (sin(a) * hh * r).toFloat()
            if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
        }
        p.close()
    }

    fun buildPath(s: ShapeLayer, sw: Float, sh: Float): Path {
        val p = Path(); val hw = sw / 2; val hh = sh / 2
        when (s.kind) {
            "RECT" -> { val r = s.corner * minOf(sw, sh); p.addRoundRect(RectF(-hw, -hh, hw, hh), r, r, Path.Direction.CW) }
            "ELLIPSE" -> p.addOval(RectF(-hw, -hh, hw, hh), Path.Direction.CW)
            "TRIANGLE" -> { p.moveTo(0f, -hh); p.lineTo(hw, hh); p.lineTo(-hw, hh); p.close() }
            "POLYGON" -> polygon(p, s.sides, hw, hh)
            "STAR" -> star(p, s.sides, s.inner, hw, hh)
            "HEART" -> {
                p.moveTo(0f, hh * 0.9f)
                p.cubicTo(-hw * 1.3f, hh * 0.1f, -hw * 0.9f, -hh * 0.95f, 0f, -hh * 0.35f)
                p.cubicTo(hw * 0.9f, -hh * 0.95f, hw * 1.3f, hh * 0.1f, 0f, hh * 0.9f)
                p.close()
            }
            "LINE" -> { p.moveTo(-hw, 0f); p.lineTo(hw, 0f) }
            "PATH" -> {
                val n = s.pts.size / 2
                if (n >= 2) {
                    var px = (s.pts[0] - 0.5f) * sw; var py = (s.pts[1] - 0.5f) * sh
                    p.moveTo(px, py)
                    for (i in 1 until n) {
                        val cx = (s.pts[2 * i] - 0.5f) * sw; val cy = (s.pts[2 * i + 1] - 0.5f) * sh
                        p.quadTo(px, py, (px + cx) / 2, (py + cy) / 2)
                        px = cx; py = cy
                    }
                    p.lineTo(px, py)
                }
            }
        }
        return p
    }

    fun draw(canvas: Canvas, w: Int, h: Int, s: ShapeLayer, ms: Long) {
        val st = animState(s.animIn, s.animOut, s.animMs, s.startMs, s.durationMs, ms, h)
        val xf = xformOf(s.kfs, (ms - s.startMs).coerceAtLeast(0), s.x, s.y, s.scale, s.rotation, s.opacity, s.trim)
        val alpha = st.alpha * xf.op
        if (alpha <= 0.01f) return
        val sw = s.w * w; val sh = s.h * w
        val path = buildPath(s, sw, sh)

        canvas.save()
        canvas.translate(xf.x * w, xf.y * h + st.dy)
        canvas.rotate(xf.rot)
        val sc = st.scale * xf.scale
        canvas.scale(sc, sc)

        if (s.hasFill && s.kind != "LINE") {
            val fp = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
            if (s.gradient) {
                val a = Math.toRadians(s.gradAngle.toDouble())
                val ax = (cos(a) * sw / 2).toFloat(); val ay = (sin(a) * sh / 2).toFloat()
                fp.shader = LinearGradient(-ax, -ay, ax, ay, s.fillColor, s.fillColor2, Shader.TileMode.CLAMP)
                fp.alpha = (255 * alpha).toInt()
            } else {
                fp.color = s.fillColor
                fp.alpha = (android.graphics.Color.alpha(s.fillColor) * alpha).toInt()
            }
            canvas.drawPath(path, fp)
        }
        if (s.strokeW > 0f) {
            val sp = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.STROKE; strokeWidth = max(s.strokeW * w, 1f)
                strokeJoin = Paint.Join.ROUND; strokeCap = Paint.Cap.ROUND
                color = s.strokeColor; this.alpha = (android.graphics.Color.alpha(s.strokeColor) * alpha).toInt()
            }
            if (xf.trim < 0.999f) {
                if (xf.trim > 0.001f) {
                    val pm = PathMeasure(path, false)
                    val seg = Path()
                    pm.getSegment(0f, pm.length * xf.trim, seg, true)
                    canvas.drawPath(seg, sp)
                }
            } else canvas.drawPath(path, sp)
        }
        canvas.restore()
    }
}

@Composable
fun ColorRow(selected: Int, onPick: (Int) -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        PALETTE.forEach { c ->
            Box(Modifier.size(30.dp).clip(CircleShape).background(Color(c))
                .border(if (c == selected) 3.dp else 1.dp, if (c == selected) MaterialTheme.colorScheme.primary else Color.Gray, CircleShape)
                .clickable { onPick(c) })
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ShapePanel(s: ShapeLayer, total: Long, kf: KfHandlers, onUpdate: (ShapeLayer, Boolean) -> Unit) {
    Column(Modifier.fillMaxWidth().heightIn(max = 230.dp).verticalScroll(rememberScrollState()).padding(horizontal = 12.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(s.name, style = MaterialTheme.typography.titleSmall, maxLines = 1)
        if (s.kind != "PATH") {
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                SHAPE_KINDS.forEach { k -> Chip(k.lowercase().replaceFirstChar { it.uppercase() }, s.kind == k) { onUpdate(s.copy(kind = k), true) } }
            }
        }
        Text("Width ${"%.2f".format(s.w)}", style = MaterialTheme.typography.labelSmall)
        Slider(value = s.w.coerceIn(0.02f, 1.5f), onValueChange = { onUpdate(s.copy(w = it), false) }, valueRange = 0.02f..1.5f)
        if (s.kind != "LINE") {
            Text("Height ${"%.2f".format(s.h)}", style = MaterialTheme.typography.labelSmall)
            Slider(value = s.h.coerceIn(0.02f, 1.5f), onValueChange = { onUpdate(s.copy(h = it), false) }, valueRange = 0.02f..1.5f)
        }
        if (s.kind == "RECT") {
            Text("Corner radius", style = MaterialTheme.typography.labelSmall)
            Slider(value = s.corner, onValueChange = { onUpdate(s.copy(corner = it), false) }, valueRange = 0f..0.5f)
        }
        if (s.kind == "POLYGON" || s.kind == "STAR") {
            Text(if (s.kind == "STAR") "Points ${s.sides}" else "Sides ${s.sides}", style = MaterialTheme.typography.labelSmall)
            Slider(value = s.sides.toFloat(), onValueChange = { onUpdate(s.copy(sides = it.roundToInt()), false) }, valueRange = 3f..12f, steps = 8)
        }
        if (s.kind == "STAR") {
            Text("Inner radius", style = MaterialTheme.typography.labelSmall)
            Slider(value = s.inner, onValueChange = { onUpdate(s.copy(inner = it), false) }, valueRange = 0.15f..0.9f)
        }
        if (s.kind != "LINE") {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Chip("Fill", s.hasFill) { onUpdate(s.copy(hasFill = !s.hasFill), true) }
                Chip("Gradient", s.gradient) { onUpdate(s.copy(gradient = !s.gradient), true) }
            }
            if (s.hasFill) {
                Text(if (s.gradient) "Gradient color 1" else "Fill color", style = MaterialTheme.typography.labelSmall)
                ColorRow(s.fillColor) { onUpdate(s.copy(fillColor = it), true) }
                if (s.gradient) {
                    Text("Gradient color 2", style = MaterialTheme.typography.labelSmall)
                    ColorRow(s.fillColor2) { onUpdate(s.copy(fillColor2 = it), true) }
                    Text("Gradient angle ${s.gradAngle.roundToInt()} deg", style = MaterialTheme.typography.labelSmall)
                    Slider(value = s.gradAngle.coerceIn(0f, 360f), onValueChange = { onUpdate(s.copy(gradAngle = it), false) }, valueRange = 0f..360f)
                }
            }
        }
        Text("Stroke width ${"%.3f".format(s.strokeW)}", style = MaterialTheme.typography.labelSmall)
        Slider(value = s.strokeW.coerceIn(0f, 0.05f), onValueChange = { onUpdate(s.copy(strokeW = it), false) }, valueRange = 0f..0.05f)
        Text("Stroke color", style = MaterialTheme.typography.labelSmall)
        ColorRow(s.strokeColor) { onUpdate(s.copy(strokeColor = it), true) }

        KeyframeControls(s.startMs, s.durationMs, s.kfs, s.x, s.y, s.scale, s.rotation, s.opacity, 0.1f..6f, kf,
            showTrim = true, trim = s.trim)

        Text("Animation in", style = MaterialTheme.typography.labelSmall)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            ANIMS.forEach { a -> Chip(a.lowercase().replaceFirstChar { it.uppercase() }, s.animIn == a) { onUpdate(s.copy(animIn = a), true) } }
        }
        Text("Animation out", style = MaterialTheme.typography.labelSmall)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            ANIMS.forEach { a -> Chip(a.lowercase().replaceFirstChar { it.uppercase() }, s.animOut == a) { onUpdate(s.copy(animOut = a), true) } }
        }
        if (total > 0) {
            val st = s.startMs.coerceIn(0, total)
            val en = (s.startMs + s.durationMs).coerceIn(st, total)
            var range by remember(s.id, s.startMs, s.durationMs) { mutableStateOf(st.toFloat()..en.toFloat()) }
            Text("Timing: ${fmt(range.start.toLong())} - ${fmt(range.endInclusive.toLong())}", style = MaterialTheme.typography.labelSmall)
            RangeSlider(value = range, onValueChange = { range = it }, valueRange = 0f..total.toFloat(),
                onValueChangeFinished = {
                    val a = range.start.toLong(); val b = range.endInclusive.toLong()
                    if (b - a >= 300) onUpdate(s.copy(startMs = a, durationMs = b - a), true)
                })
        }
        LayerFxControls(s.fx) { nf, rec -> onUpdate(s.copy(fx = nf), rec) }
        Spacer(Modifier.height(6.dp))
    }
}
