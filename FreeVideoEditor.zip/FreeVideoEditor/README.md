# KitCut (v0.9 - Part 8: Mask, Transitions, Freeze)

Kotlin + Jetpack Compose + Media3. No ads, watermark, account, or paywall.

## Build the APK on GitHub
1. Create a GitHub repo, push this folder to `main`.
2. Open the **Actions** tab, run "Build APK" (it also runs on every push).
3. Download `FreeVideoEditor-debug-apk` from the run's **Artifacts**, unzip, install the .apk.

Local: `gradle assembleDebug` (Gradle 8.7, JDK 17, Android SDK 34).

## Implemented (Stage 1-4 + basic Stage 7)
Home + persistent projects (JSON, atomic save), multi-video import (SAF), live preview (ExoPlayer),
single-track timeline with zoom, split, trim, duplicate, delete, reorder, undo/redo,
real H.264/AAC MP4 export (Media3 Transformer) with progress + cancel.

## Not yet implemented
Multitrack/overlays, text, audio tracks, filters/effects, transitions, keyframes, canvas ratios,
export settings UI, waveforms/thumbnails, relink missing media, crash-recovery of exports.
Exports are saved to the app's Movies folder (Android/data/com.freeeditor.app/files/Movies).

## Licenses
Media3 (Apache 2.0), Jetpack Compose (Apache 2.0). No FFmpeg bundled.

## Status
Code was written without a compile check; if the first GitHub build shows errors, send me the log.

## Part 2 additions
- Import from the phone gallery (system photo picker, no storage permission). Photos become 3 s clips.
- Text overlays: add/edit, 5 fonts + bold/italic, size, color, outline, shadow, 6 presets,
  in/out animations (fade/slide/pop), timing on a text track, drag to position, duplicate/delete.
- Preview and export share one text renderer, so exported text matches the preview.
- Export now scales all clips to the first clip's frame size (letterboxed).

## Part 3 additions
- Audio: music import, voice recording, extract audio from video, separate audio lanes with real
  waveforms, volume, fade in/out, start/trim, split/duplicate/delete, per-clip video volume.
  Preview and export both apply volume and fades.
- Smoother timeline: frame-locked playhead loop, no timeline recomposition during playback,
  fast seeking while scrubbing.
- In-app updates (Home screen): checks the latest GitHub Release, downloads the APK and opens the installer.
- Fixed signing key (keystore/release.jks) so every build can update the previous one.
  The repo must be PUBLIC for in-app update checks to work.

## Part 4 additions (layer system)
- Image/sticker overlay layers from the gallery, alongside text layers.
- Touch transform on the preview: drag to move, pinch to scale, two-finger rotate.
- Opacity, rotation, scale sliders for every layer; fade/slide/pop in-out animations.
- Layers panel: select, rename, show/hide, lock, reorder (z-order), delete.
- Overlay lanes on the timeline (text and images share lanes automatically).
- One shared renderer draws all overlay layers for both preview and export.
Planned next: Part 5 keyframes + easing.

## Part 5 additions (keyframes + easing)
- Keyframes on position, scale, rotation, opacity for text and image layers (diamond buttons, prev/next).
- Auto-keyframe: moving/pinching/rotating on the preview or using sliders writes a keyframe when a property is animated.
- Cubic-bezier easing per keyframe: presets (linear, ease in/out, overshoot) and a draggable curve editor.
- Motion path preview, keyframe markers on the timeline; preview and export share the same evaluator.
- Compact update button on Home (dot when an update exists), overlay photos honor EXIF rotation,
  timeline zoom is capped for very long projects, undo history capped at 100.
Not included: audio-volume keyframes, keyframes on video clips (planned later).

## Part 6 additions (shapes and vectors) + UI
- Shape layers: rectangle (corner radius), ellipse, triangle, polygon, star, heart, line.
- Solid or two-color gradient fill with angle, stroke color/width, size sliders.
- Freehand pen (Draw) creates a smoothed vector path layer.
- Trim-path animation (keyframable) to draw outlines on.
- Shapes use the same layer system: touch transform, keyframes/easing, z-order, hide/lock, timeline lanes.
- App renamed KitCut with a new K logo. Undo/Redo moved next to the playback controls.
- Bottom bar is Alight Motion style: big + button opens an Add sheet (Media, Overlay, Text, Music, Record, Shapes, Draw).
- Project cards on Home show a preview frame, duration and clip count.
Not included yet: SVG import, boolean path operations, point-by-point pen editing.

## Part 7 additions
- Clip effects (select a clip, tap Effects): 8 filters with intensity, brightness, contrast, saturation, warmth.
- Clip motion: zoom in/out, pulse, shake. Vignette per clip.
- Layer effects (text/image/shape): shadow, glow (colored), blur, brightness/contrast/saturation.
- Preview uses the same Media3 effect objects as the exporter. Not yet compiled or run on a device.
- Not done: blend modes against video, video blur/RGB split/glitch/chroma key (need custom GL shaders), keyframing effects.

## Part 8 additions
- Alight Motion-style layout: bottom Add panel with tabs, right rail (Draw/Text/Close), transport row, rename in header, icon export.
- Smooth sliders (throttled, final value always sent); preview effects debounced; player no longer reloaded on slider changes.
- Layers (text/image/shape/audio) draggable on the timeline (long-press then drag) and trimmable with edge handles when selected.
- Layer mask: rect/ellipse/triangle/star/heart, position, size, rotation, feather, invert.
- Clip transitions in/out: fade, white flash, zoom, slide + duration. Freeze frame. Flip H/V and rotate 90.
- Not done: speed/reverse/speed ramp, mask on video, true cross-dissolve between clips.
